# ICE CLIENT 26.2 — Premium Frozen Edition

**Developer:** @drtranhung2611  
**Minecraft:** 26.2 | **Fabric Loader:** ≥0.19.3 | **Java:** 25  
**Mappings:** Official Mojang

## Highlights

### Intro Cinematic (once per session)
Black → ice crystal appears & blooms → cracks → shatter + flash → logo fade-in → smooth handoff to Title Screen.  
Click / ESC to skip after ~0.6 s. Toggle via `IceIntroScreen.ENABLED`.

### Frozen Main Menu
- Custom `IceTitleScreen` replaces vanilla TitleScreen
- Animated snow particles
- Cold blue gradient + vignette
- Frosted glass buttons (Singleplayer / Multiplayer / Realms / Options / Language / Quit)
- Hover glow + pulse logo
- Credit: ICE CLIENT 26.2 · Developed by @drtranhung2611

### ICE PRO ClickGUI (Right Shift)
Sidebar categories · module cards · search · right settings panel · drag · animations · chroma option · config tab.

### Modules
Combat (AutoCrystal, AutoAnchor, AutoPush, Surround, Velocity), Movement, Player, Render (ESP suite), Misc, HUD (Watermark, ArrayList, Coords, FPS/Ping, Armor, Notifications…).

## Build
```bash
export JAVA_HOME=…/java-25   # Java 25 required
bash gradlew clean build
# → build/libs/iceclient-26.2.jar  (also copied as ICECLIENT-26.2.jar)
```

## Install
Drop `ICECLIENT-26.2.jar` + matching Fabric API into `.minecraft/mods`.

No anti-cheat bypass / packet spoofing beyond legitimate module behaviour. Client-side only.
