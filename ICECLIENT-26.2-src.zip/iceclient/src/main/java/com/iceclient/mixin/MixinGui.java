package com.iceclient.mixin;

import com.iceclient.client.Ice;
import com.iceclient.gui.screens.IceIntroScreen;
import com.iceclient.gui.screens.IceTitleScreen;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Intercepts vanilla TitleScreen and replaces it with ICE Intro / Title.
 * Plays the cinematic once per session (or immediately shows title if intro disabled).
 */
@Mixin(Gui.class)
public abstract class MixinGui {

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen iceclient$replaceTitle(Screen screen) {
        if (screen instanceof TitleScreen) {
            if (IceIntroScreen.ENABLED && !Ice.INTRO_PLAYED) {
                return new IceIntroScreen();
            }
            // Always use our branded title screen instead of vanilla
            return new IceTitleScreen();
        }
        return screen;
    }
}
