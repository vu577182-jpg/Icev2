package com.iceclient.client;

import com.iceclient.event.EventBus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class Ice {
    public static final String NAME = "ICE CLIENT";
    public static final String VERSION = "26.2";
    public static final String DEVELOPER = "@drtranhung2611";
    public static final Logger LOGGER = LogManager.getLogger("ICECLIENT");
    public static final EventBus EVENTS = new EventBus();

    /** True after the intro cinematic has played (or been skipped) this session. */
    public static boolean INTRO_PLAYED = false;

    private Ice() {}
}
