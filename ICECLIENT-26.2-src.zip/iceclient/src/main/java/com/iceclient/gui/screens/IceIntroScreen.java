package com.iceclient.gui.screens;

import com.iceclient.client.Ice;
import com.iceclient.util.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * ICE CLIENT Intro Cinematic — once per session.
 * Black → crystal bloom → cracks → shatter + flash → logo → TitleScreen.
 * Skip with click / ESC after 0.6s.
 */
public final class IceIntroScreen extends Screen {

    private static final class Shard {
        float x, y, vx, vy, size, life, rot;
        Shard(float x, float y, float vx, float vy, float size) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.size = size; this.life = 1f; this.rot = 0;
        }
    }

    private final long startMs = System.currentTimeMillis();
    private final List<Shard> shards = new ArrayList<>();
    private final Random rng = new Random(42);
    private boolean finished = false;
    private float skipAlpha = 0f;
    private final Minecraft mc = Minecraft.getInstance();

    public static boolean ENABLED = true;

    public IceIntroScreen() {
        super(Component.literal("ICE CLIENT Intro"));
    }

    private float elapsed() {
        return (System.currentTimeMillis() - startMs) / 1000f;
    }

    @Override
    public void tick() {
        float t = elapsed();
        if (t > 5.5f && !finished) finish();
        for (Shard s : shards) {
            s.x += s.vx;
            s.y += s.vy;
            s.vy += 0.14f;
            s.rot += 0.09f;
            s.life -= 0.016f;
        }
        shards.removeIf(s -> s.life <= 0);
        skipAlpha = Math.min(1f, skipAlpha + 0.05f);
    }

    private void finish() {
        if (finished) return;
        finished = true;
        Ice.INTRO_PLAYED = true;
        mc.gui.setScreen(new IceTitleScreen());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, g.guiWidth(), g.guiHeight(), 0xFF000000);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partialTick) {
        int sw = g.guiWidth(), sh = g.guiHeight();
        float t = elapsed();
        float cx = sw / 2f, cy = sh / 2f;

        if (t < 1.1f) {
            float p = t / 1.1f;
            float scale = 0.15f + p * 0.95f;
            int ca = (int) (p * 255);
            drawCrystal(g, cx, cy, 56 * scale, Theme.alpha(Theme.PRIMARY, ca));
            for (int i = 0; i < 8; i++) {
                int r = (int) (20 + i * 22 * p);
                int a = Math.max(1, (int)(p * 28) - i * 3);
                g.fill((int)cx - r, (int)cy - r, (int)cx + r, (int)cy + r, Theme.alpha(0x1A4A6E, a));
            }
        } else if (t < 2.6f) {
            float p = (t - 1.1f) / 1.5f;
            float scale = 1.0f + p * 0.4f;
            drawCrystal(g, cx, cy, 56 * scale, Theme.PRIMARY);
            drawCracks(g, cx, cy, 56 * scale, p);
            int a = (int)(0x12 + p * 0x20);
            g.fill(0, 0, sw, sh, Theme.alpha(0x0A2035, a));
        } else if (t < 3.7f) {
            float p = (t - 2.6f) / 1.1f;
            if (shards.isEmpty() && p < 0.12f) spawnShards(cx, cy);
            if (p < 0.3f) {
                int fa = (int)((1f - p / 0.3f) * 0xB0);
                g.fill(0, 0, sw, sh, Theme.alpha(0x88DDFF, fa));
            }
            for (Shard s : shards) {
                int a = (int)(s.life * 230);
                drawShard(g, s.x, s.y, s.size, Theme.alpha(Theme.SECONDARY, a));
            }
        } else {
            float p = Math.min(1f, (t - 3.7f) / 1.5f);
            int logoA = (int)(p * 255);
            drawCenteredGlowText(g, "ICE CLIENT", sw / 2, sh / 2 - 24, Theme.alpha(Theme.PRIMARY, logoA), 0.65f + p * 0.35f);
            drawCenteredText(g, "26.2", sw / 2, sh / 2 + 8, Theme.alpha(Theme.SECONDARY, logoA));
            drawCenteredText(g, "Developed by " + Ice.DEVELOPER, sw / 2, sh / 2 + 28, Theme.alpha(Theme.MUTED, (int)(logoA * 0.85f)));
            for (Shard s : shards) {
                int a = (int)(s.life * 160);
                drawShard(g, s.x, s.y, s.size, Theme.alpha(Theme.GLOW, a));
            }
            for (int i = 0; i < 40; i++) {
                int a = (int)((40 - i) * 2.2f * (1f - p * 0.4f));
                g.fill(0, i, sw, i + 1, Theme.alpha(0x020810, a));
                g.fill(0, sh - i - 1, sw, sh - i, Theme.alpha(0x020810, a));
            }
        }

        if (skipAlpha > 0.05f && t > 0.7f) {
            int a = (int)(skipAlpha * 0xA0);
            String skip = "Click or press ESC to skip";
            var font = mc.font;
            int tw = font.width(skip);
            g.text(font, skip, sw / 2 - tw / 2, sh - 30, Theme.alpha(Theme.MUTED, a));
        }
    }

    private void spawnShards(float cx, float cy) {
        for (int i = 0; i < 36; i++) {
            float ang = (float)(i * (Math.PI * 2 / 36) + rng.nextFloat() * 0.25);
            float sp = 2.8f + rng.nextFloat() * 6.5f;
            shards.add(new Shard(cx, cy,
                    (float)Math.cos(ang) * sp,
                    (float)Math.sin(ang) * sp - 1.8f,
                    2.5f + rng.nextFloat() * 7f));
        }
    }

    private void drawCrystal(GuiGraphicsExtractor g, float cx, float cy, float size, int color) {
        int s = (int) size;
        fillDiamond(g, (int)cx, (int)cy, s, color);
        fillDiamond(g, (int)cx, (int)cy, s / 2, Theme.alpha(0xFFFFFF, 0x45));
        g.fill((int)cx, (int)(cy - s), (int)cx + 1, (int)(cy + s), Theme.alpha(0xFFFFFF, 0x35));
        for (int i = 0; i < 4; i++) {
            float ang = (float)(i * Math.PI / 2 + 0.4);
            int x2 = (int)(cx + Math.cos(ang) * s * 0.85);
            int y2 = (int)(cy + Math.sin(ang) * s * 0.85);
            for (int k = 0; k < s; k++) {
                float f = k / (float)s;
                int px = (int)(cx + (x2 - cx) * f);
                int py = (int)(cy + (y2 - cy) * f);
                g.fill(px, py, px + 1, py + 1, Theme.alpha(0xFFFFFF, 0x25));
            }
        }
    }

    private void fillDiamond(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = r - Math.abs(dy);
            if (half > 0) g.fill(cx - half, cy + dy, cx + half, cy + dy + 1, color);
        }
    }

    private void drawCracks(GuiGraphicsExtractor g, float cx, float cy, float size, float progress) {
        int s = (int) size;
        int a = (int)(progress * 0xD0);
        int col = Theme.alpha(0xA0D8FF, a);
        for (int i = 0; i < 5; i++) {
            float ang = (float)(i * Math.PI * 2 / 5 + 0.3);
            int steps = (int)(s * progress);
            for (int k = 0; k < steps; k++) {
                float f = k / (float)Math.max(1, steps);
                int px = (int)(cx + Math.cos(ang) * s * f);
                int py = (int)(cy + Math.sin(ang) * s * f);
                g.fill(px, py, px + 1, py + 1, col);
                if (k % 7 == 0 && k > 0) {
                    float ba = ang + 0.6f;
                    for (int b = 0; b < 6; b++) {
                        int bx = (int)(px + Math.cos(ba) * b * 1.5);
                        int by = (int)(py + Math.sin(ba) * b * 1.5);
                        g.fill(bx, by, bx + 1, by + 1, Theme.alpha(0xA0D8FF, a / 2));
                    }
                }
            }
        }
    }

    private void drawShard(GuiGraphicsExtractor g, float x, float y, float size, int color) {
        int s = Math.max(1, (int) size);
        fillDiamond(g, (int)x, (int)y, s, color);
    }

    private void drawCenteredText(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        var font = mc.font;
        g.text(font, s, cx - font.width(s) / 2, y, color);
    }

    private void drawCenteredGlowText(GuiGraphicsExtractor g, String s, int cx, int y, int color, float intensity) {
        var font = mc.font;
        int x = cx - font.width(s) / 2;
        int ga = (int)(0x30 * intensity);
        g.text(font, s, x - 1, y, Theme.alpha(color, ga));
        g.text(font, s, x + 1, y, Theme.alpha(color, ga));
        g.text(font, s, x, y, color);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (elapsed() > 0.55f) { finish(); return true; }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (elapsed() > 0.55f) { finish(); return true; }
        return super.keyPressed(event);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
}
