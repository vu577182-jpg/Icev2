package com.iceclient.gui.screens;

import com.iceclient.client.Ice;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.LanguageSelectScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import com.mojang.realmsclient.RealmsMainScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * ICE CLIENT — Frozen Main Menu
 * Dense animated snow, frost vignette, glowing logo, frosted buttons.
 * Assets (crystal/logo/snow textures) are shipped in the JAR for future use / resource packs.
 */
public final class IceTitleScreen extends Screen {

    private static final class Snowflake {
        float x, y, speed, size, alpha, drift;
        Snowflake(float x, float y, float speed, float size, float alpha, float drift) {
            this.x = x; this.y = y; this.speed = speed; this.size = size;
            this.alpha = alpha; this.drift = drift;
        }
    }

    private static final class Floater {
        float x, y, vx, vy, size, rot, alpha;
        Floater(float x, float y, float vx, float vy, float size) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.size = size; this.rot = 0; this.alpha = 0.4f + (float)Math.random()*0.5f;
        }
    }

    private static final class MenuButton {
        final String label;
        final Runnable action;
        int x, y, w, h;
        float hover;
        MenuButton(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Snowflake> snow = new ArrayList<>();
    private final List<Floater> floaters = new ArrayList<>();
    private final List<MenuButton> buttons = new ArrayList<>();
    private final Random rng = new Random();
    private float logoPulse = 0f;
    private float time = 0f;
    private final Minecraft mc = Minecraft.getInstance();

    public IceTitleScreen() {
        super(Component.literal("ICE CLIENT"));
        buttons.add(new MenuButton("Singleplayer", () -> mc.gui.setScreen(new SelectWorldScreen(this))));
        buttons.add(new MenuButton("Multiplayer",  () -> mc.gui.setScreen(new JoinMultiplayerScreen(this))));
        buttons.add(new MenuButton("Realms",       () -> mc.gui.setScreen(new RealmsMainScreen(this))));
        buttons.add(new MenuButton("Options",      () -> mc.gui.setScreen(new OptionsScreen(this, mc.options, false))));
        buttons.add(new MenuButton("Language",     () -> mc.gui.setScreen(new LanguageSelectScreen(this, mc.options, mc.getLanguageManager()))));
        buttons.add(new MenuButton("Quit Game",    () -> mc.stop()));
    }

    @Override
    public void tick() {
        time += 0.05f;
        logoPulse += 0.045f;
        int w = Math.max(width, 854);
        int h = Math.max(height, 480);

        for (Snowflake s : snow) {
            s.y += s.speed;
            s.x += Math.sin((s.y + s.size) * 0.018 + s.drift) * 0.45f;
            if (s.y > h + 12) {
                s.y = -12;
                s.x = rng.nextFloat() * w;
            }
        }
        while (snow.size() < 220) {
            snow.add(new Snowflake(
                    rng.nextFloat() * w, rng.nextFloat() * h,
                    0.35f + rng.nextFloat() * 1.8f,
                    1.0f + rng.nextFloat() * 2.8f,
                    0.25f + rng.nextFloat() * 0.65f,
                    rng.nextFloat() * 6.28f
            ));
        }

        for (Floater f : floaters) {
            f.x += f.vx;
            f.y += f.vy;
            f.rot += 0.03f;
            if (f.x < -20 || f.x > w + 20 || f.y < -20 || f.y > h + 20) {
                f.x = rng.nextFloat() * w;
                f.y = rng.nextFloat() * h;
            }
        }
        while (floaters.size() < 18) {
            floaters.add(new Floater(
                    rng.nextFloat() * w, rng.nextFloat() * h,
                    (rng.nextFloat() - 0.5f) * 0.4f,
                    (rng.nextFloat() - 0.5f) * 0.3f,
                    4f + rng.nextFloat() * 10f
            ));
        }
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        int sw = g.guiWidth(), sh = g.guiHeight();
        // Deep frozen base
        g.fill(0, 0, sw, sh, 0xFF020810);
        // Vertical blue wash layers
        for (int i = 0; i < 12; i++) {
            int a = 6 + i * 2;
            int y0 = (sh * i) / 12;
            int y1 = (sh * (i + 1)) / 12;
            g.fill(0, y0, sw, y1, Theme.alpha(0x061428, a));
        }
        // Soft top cold light
        for (int i = 0; i < 50; i++) {
            int a = Math.max(0, 36 - i);
            g.fill(0, i * 2, sw, i * 2 + 2, Theme.alpha(0x1A3A5C, a));
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partialTick) {
        int sw = g.guiWidth(), sh = g.guiHeight();

        // Floating ice crystals (procedural diamonds)
        for (Floater f : floaters) {
            int a = (int) (f.alpha * 160);
            drawMiniCrystal(g, f.x, f.y, f.size, Theme.alpha(Theme.PRIMARY, a));
        }

        // Dense snow
        for (Snowflake s : snow) {
            int a = (int) (s.alpha * 255) & 0xFF;
            int c = Theme.alpha(0xE8F6FF, a);
            int sz = Math.max(1, (int) s.size);
            g.fill((int) s.x, (int) s.y, (int) s.x + sz, (int) s.y + sz, c);
            // soft blur pixel
            if (sz > 1) {
                g.fill((int) s.x - 1, (int) s.y, (int) s.x, (int) s.y + sz, Theme.alpha(0xE8F6FF, a / 3));
            }
        }

        // Frost vignette edges
        drawVignette(g, sw, sh);

        // Logo block
        float pulse = 0.82f + 0.18f * (float) Math.sin(logoPulse);
        int logoY = Math.max(32, sh / 8);
        drawCenteredGlowText(g, "ICE CLIENT", sw / 2, logoY, Theme.PRIMARY, pulse);
        drawCenteredText(g, "26.2  ·  PREMIUM FROZEN EDITION", sw / 2, logoY + 30, Theme.SECONDARY);
        drawCenteredText(g, "Developed by " + Ice.DEVELOPER, sw / 2, logoY + 48, Theme.MUTED);

        // Ice accent line
        int lineW = 200;
        int lx = sw / 2 - lineW / 2;
        int ly = logoY + 66;
        Render2D.rect(g, lx, ly, lineW, 1, Theme.alpha(Theme.PRIMARY, 0xA0));
        Render2D.rect(g, lx + 30, ly + 2, lineW - 60, 1, Theme.alpha(Theme.GLOW, 0x50));

        // Buttons
        int btnW = 220;
        int btnH = 30;
        int gap = 7;
        int totalH = buttons.size() * (btnH + gap) - gap;
        int startY = Math.min(sh - totalH - 48, logoY + 95);
        int bx = sw / 2 - btnW / 2;

        for (int i = 0; i < buttons.size(); i++) {
            MenuButton b = buttons.get(i);
            b.x = bx;
            b.y = startY + i * (btnH + gap);
            b.w = btnW;
            b.h = btnH;
            boolean hovered = b.contains(mx, my);
            b.hover += ((hovered ? 1f : 0f) - b.hover) * 0.28f;
            drawFrostButton(g, b);
        }

        // Footer
        drawCenteredText(g, Ice.NAME + "  " + Ice.VERSION + "  ·  Fabric", sw / 2, sh - 20, Theme.alpha(Theme.MUTED, 0xA0));
    }

    private void drawVignette(GuiGraphicsExtractor g, int sw, int sh) {
        int edge = Math.min(80, Math.min(sw, sh) / 6);
        for (int i = 0; i < edge; i++) {
            int a = (int) ((edge - i) * 1.8f);
            // top / bottom
            g.fill(0, i, sw, i + 1, Theme.alpha(0x020810, Math.min(180, a)));
            g.fill(0, sh - i - 1, sw, sh - i, Theme.alpha(0x020810, Math.min(180, a)));
            // left / right
            g.fill(i, 0, i + 1, sh, Theme.alpha(0x020810, Math.min(160, a)));
            g.fill(sw - i - 1, 0, sw - i, sh, Theme.alpha(0x020810, Math.min(160, a)));
        }
    }

    private void drawMiniCrystal(GuiGraphicsExtractor g, float cx, float cy, float size, int color) {
        int s = Math.max(2, (int) size);
        for (int dy = -s; dy <= s; dy++) {
            int half = s - Math.abs(dy);
            if (half > 0) {
                g.fill((int) cx - half, (int) cy + dy, (int) cx + half, (int) cy + dy + 1, color);
            }
        }
    }

    private void drawFrostButton(GuiGraphicsExtractor g, MenuButton b) {
        int bg = Theme.lerp(Theme.CARD, Theme.CARD_HOVER, b.hover);
        int border = Theme.lerp(Theme.BORDER, Theme.PRIMARY, b.hover);
        int textCol = Theme.lerp(Theme.TEXT, 0xFFFFFFFF, b.hover * 0.35f);

        if (b.hover > 0.04f) {
            int ga = (int) (b.hover * 0x55);
            Render2D.rect(g, b.x - 3, b.y - 3, b.w + 6, b.h + 6, Theme.alpha(Theme.GLOW, ga));
        }

        Render2D.roundedRect(g, b.x, b.y, b.w, b.h, 5, bg);
        Render2D.outline(g, b.x, b.y, b.w, b.h, Theme.alpha(border, 0xD0));
        // top frost highlight
        Render2D.rect(g, b.x + 2, b.y + 1, b.w - 4, 1, Theme.alpha(0xFFFFFF, (int) (0x1A + b.hover * 0x28)));

        var font = mc.font;
        int tw = font.width(b.label);
        int tx = b.x + (b.w - tw) / 2;
        int ty = b.y + (b.h - 8) / 2;
        g.text(font, b.label, tx, ty, textCol);
    }

    private void drawCenteredText(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        var font = mc.font;
        int tw = font.width(s);
        g.text(font, s, cx - tw / 2, y, color);
    }

    private void drawCenteredGlowText(GuiGraphicsExtractor g, String s, int cx, int y, int color, float intensity) {
        var font = mc.font;
        int tw = font.width(s);
        int x = cx - tw / 2;
        int ga = (int) (0x38 * intensity);
        g.text(font, s, x - 1, y, Theme.alpha(color, ga));
        g.text(font, s, x + 1, y, Theme.alpha(color, ga));
        g.text(font, s, x, y - 1, Theme.alpha(color, ga));
        g.text(font, s, x, y + 1, Theme.alpha(color, ga));
        g.text(font, s, x, y, color);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        for (MenuButton b : buttons) {
            if (b.contains(mx, my)) {
                b.action.run();
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
}
