package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.StringSetting;

/** Appends a suffix to outgoing chat messages. */
public final class ChatAppend extends Module {
    public final StringSetting suffix = add(new StringSetting("Suffix", "Text appended to chat", " | ICE"));

    public ChatAppend() {
        super("ChatAppend", "Them hau to vao tin nhan chat.", Category.MISC);
    }

    public String process(String original) {
        if (!isEnabled() || original == null || original.startsWith("/")) return original;
        return original + suffix.get();
    }
}
