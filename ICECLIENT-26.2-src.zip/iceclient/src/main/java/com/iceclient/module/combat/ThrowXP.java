package com.iceclient.module.combat;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/** Throws experience bottles when enabled (manual helper, no auto-target exploit). */
public final class ThrowXP extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay", "Ticks between throws", 2, 0, 20, 1));
    public final BooleanSetting mainHand = add(new BooleanSetting("MainHand", "Prefer main hand", true));

    private int timer;

    public ThrowXP() {
        super("ThrowXP", "Nem binh kinh nghiem khi bat.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (timer > 0) { timer--; return; }
        InteractionHand hand = mainHand.on() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        if (mc.player.getItemInHand(hand).is(Items.EXPERIENCE_BOTTLE)) {
            mc.gameMode.useItem(mc.player, hand);
            timer = delay.i();
        }
    }
}
