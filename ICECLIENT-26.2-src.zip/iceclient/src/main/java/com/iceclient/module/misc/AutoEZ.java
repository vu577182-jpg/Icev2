package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.StringSetting;
import net.minecraft.network.chat.Component;

/** Sends a configurable message on player death (client-side chat only). */
public final class AutoEZ extends Module {
    public final StringSetting message = add(new StringSetting("Message", "Chat message", "EZ - ICE CLIENT"));

    public AutoEZ() {
        super("AutoEZ", "Gui tin nhan khi ban chet nguoi choi.", Category.MISC);
    }

    /** Call from death/kill detection if available. */
    public void onKill(String name) {
        if (!isEnabled() || mc.player == null) return;
        String msg = message.get().replace("{name}", name == null ? "player" : name);
        mc.player.connection.sendChat(msg);
    }
}
