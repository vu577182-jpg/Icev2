package com.iceclient.module.client;

import com.iceclient.module.Category;
import com.iceclient.module.Module;

import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Simple friend list (name-based). Used by ESP / combat filters. */
public final class Friend extends Module {
    private static final Set<String> FRIENDS = new HashSet<>();

    public Friend() {
        super("Friend", "Quan ly danh sach ban be.", Category.CLIENT);
        setEnabledSilently(true);
    }

    public static boolean isFriend(String name) {
        if (name == null) return false;
        return FRIENDS.contains(name.toLowerCase(Locale.ROOT));
    }

    public static void add(String name) {
        if (name != null) FRIENDS.add(name.toLowerCase(Locale.ROOT));
    }

    public static void remove(String name) {
        if (name != null) FRIENDS.remove(name.toLowerCase(Locale.ROOT));
    }

    public static Set<String> all() {
        return Collections.unmodifiableSet(FRIENDS);
    }

    @Override
    protected boolean requiresWorld() { return false; }
}
