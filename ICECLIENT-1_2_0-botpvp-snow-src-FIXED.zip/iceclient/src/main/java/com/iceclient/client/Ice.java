package com.iceclient.client;

import com.iceclient.event.EventBus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class Ice {
    public static final String NAME = "ICECLIENT";
    public static final String VERSION = "26.2-1.0.0";
    public static final Logger LOGGER = LogManager.getLogger(NAME);
    public static final EventBus EVENTS = new EventBus();

    private Ice() {}
}
