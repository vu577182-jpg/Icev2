package com.iceclient.mixin;

import com.iceclient.module.combat.Freecam;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public class FreecamMouseMixin {

    /**
     * Inject vào đầu MouseHandler.turnPlayer() để bắt mouse delta.
     * Khi Freecam bật: forward delta tới Freecam.onMouseTurn() rồi cancel vanilla.
     *
     * Tên method mapped:
     *   mojmap: turnPlayer
     *   yarn:   updateMouse / turn
     * Nếu fail thử "updateMouse" hoặc "turn".
     */
    @Inject(
        method = "turnPlayer",
        at = @At("HEAD"),
        cancellable = true
    )
    private void freecam$turnPlayer(double dx, double dy, CallbackInfo ci) {
        if (!Freecam.active) return;
        Freecam.onMouseTurn(dx, dy);
        ci.cancel();
    }
}
