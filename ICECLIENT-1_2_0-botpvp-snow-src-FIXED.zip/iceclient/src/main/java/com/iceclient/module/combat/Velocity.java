package com.iceclient.module.combat;

import com.iceclient.client.Ice;
import com.iceclient.event.PacketEvent;
import com.iceclient.mixin.AccessorClientboundExplodePacket;
import com.iceclient.mixin.AccessorClientboundSetEntityMotionPacket;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
import java.util.function.Consumer;

/** Scales (or removes) knockback the server sends to the local player. */
public final class Velocity extends Module {
    private final NumberSetting horizontal = add(new NumberSetting("Horizontal", "Horizontal knockback in percent", 0, 0, 100, 1));
    private final NumberSetting vertical = add(new NumberSetting("Vertical", "Vertical knockback in percent", 0, 0, 100, 1));
    private final BooleanSetting explosions = add(new BooleanSetting("Explosions", "Also scale explosion knockback", true));

    private Consumer<PacketEvent.Receive> handler;

    public Velocity() {
        super("Velocity", "Giam hoac loai bo knockback nhan tu server.", Category.COMBAT);
    }

    @Override public String info() { return (int) horizontal.d() + "% " + (int) vertical.d() + "%"; }

    @Override
    protected void onEnable() {
        handler = Ice.EVENTS.subscribe(PacketEvent.Receive.class, this::onPacket);
    }

    @Override
    protected void onDisable() {
        if (handler != null) Ice.EVENTS.unsubscribe(PacketEvent.Receive.class, handler);
        handler = null;
    }

    private void onPacket(PacketEvent.Receive event) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        double h = horizontal.d() / 100.0, v = vertical.d() / 100.0;

        if (event.packet instanceof ClientboundSetEntityMotionPacket motion && motion.id() == p.getId()) {
            if (h == 0 && v == 0) {
                event.cancel();
                return;
            }
            Vec3 m = motion.movement();
            ((AccessorClientboundSetEntityMotionPacket) (Object) motion)
                    .iceclient$setMovement(new Vec3(m.x * h, m.y * v, m.z * h));
        } else if (explosions.on() && event.packet instanceof ClientboundExplodePacket explode) {
            Optional<Vec3> kb = explode.playerKnockback();
            if (kb.isPresent()) {
                Vec3 m = kb.get();
                ((AccessorClientboundExplodePacket) (Object) explode)
                        .iceclient$setPlayerKnockback(Optional.of(new Vec3(m.x * h, m.y * v, m.z * h)));
            }
        }
    }
}
