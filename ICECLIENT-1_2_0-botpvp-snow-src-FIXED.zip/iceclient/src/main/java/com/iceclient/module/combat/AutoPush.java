package com.iceclient.module.combat;

import com.iceclient.manager.NotificationManager;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.BlockUtil;
import com.iceclient.util.InventoryUtil;
import com.iceclient.util.RotationUtil;
import com.iceclient.util.TargetUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Builds a piston + redstone block next to the target so the piston arm pushes them sideways. */
public final class AutoPush extends Module {
    private final NumberSetting targetRange = add(new NumberSetting("TargetRange", "Max distance to pick a target", 5, 2, 8, 0.5));
    private final NumberSetting delay = add(new NumberSetting("Delay", "Ticks between placements", 2, 0, 10, 1));
    private final BooleanSetting disableAfter = add(new BooleanSetting("DisableAfter", "Turn off once the redstone block is placed", true));

    private int timer;

    public AutoPush() {
        super("AutoPush", "Dat piston + redstone de day muc tieu ra khoi vi tri.", Category.COMBAT);
    }

    @Override
    protected String checkCanEnable() {
        if (InventoryUtil.findHotbar(Items.PISTON) == -1) return "Can piston tren hotbar";
        if (InventoryUtil.findHotbar(Items.REDSTONE_BLOCK) == -1) return "Can redstone block tren hotbar";
        return null;
    }

    @Override
    protected void onEnable() { timer = 0; }

    @Override
    public void onTick() {
        if (timer > 0) { timer--; return; }
        LocalPlayer p = mc.player;
        Player target = TargetUtil.nearestPlayer(targetRange.d());
        if (target == null) return;

        BlockPos t = target.blockPosition();
        for (Direction push : Direction.Plane.HORIZONTAL) {
            BlockPos piston = t.relative(push.getOpposite());
            BlockPos redstone = piston.relative(push.getOpposite());
            BlockPos dest = t.relative(push);

            var pistonState = mc.level.getBlockState(piston);
            boolean pistonPlaced = pistonState.getBlock() == Blocks.PISTON;
            if (!pistonPlaced && !pistonState.isAir()) continue;
            if (!BlockUtil.isAir(dest) || !BlockUtil.isAir(dest.above())) continue;
            var rsState = mc.level.getBlockState(redstone);
            boolean redstonePlaced = rsState.getBlock() == Blocks.REDSTONE_BLOCK;
            if (!redstonePlaced && !rsState.isAir()) continue;
            if (p.getEyePosition().distanceToSqr(Vec3.atCenterOf(piston)) > BlockUtil.REACH_SQ) continue;

            int previous = InventoryUtil.selected();
            try {
                if (!pistonPlaced) {
                    if (!BlockUtil.hasSupport(piston)) continue;
                    int slot = InventoryUtil.findHotbar(Items.PISTON);
                    if (slot == -1) return;
                    InventoryUtil.select(slot);
                    // A piston faces the opposite of the placer's look direction, so look away from the push direction.
                    RotationUtil.send(push.getOpposite().toYRot(), 0f);
                    if (BlockUtil.place(piston, InteractionHand.MAIN_HAND, false)) timer = delay.i();
                } else if (!redstonePlaced) {
                    int slot = InventoryUtil.findHotbar(Items.REDSTONE_BLOCK);
                    if (slot == -1) return;
                    InventoryUtil.select(slot);
                    if (BlockUtil.place(redstone, InteractionHand.MAIN_HAND, true)) timer = delay.i();
                } else if (disableAfter.on()) {
                    NotificationManager.info(name, "Da dat xong");
                    setEnabled(false);
                }
            } finally {
                InventoryUtil.select(previous);
            }
            return;
        }
    }
}
