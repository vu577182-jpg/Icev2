package com.iceclient.module.render;

import com.iceclient.mixin.AccessorOptionInstance;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.NumberSetting;
import net.minecraft.client.OptionInstance;

public final class FullBright extends Module {
    private final NumberSetting gamma = add(new NumberSetting("Gamma", "Brightness value applied while enabled", 15, 2, 20, 1));
    private double previous = 1.0;

    public FullBright() {
        super("FullBright", "Sang toi da, nhin ro trong bong toi.", Category.RENDER);
    }

    @Override protected boolean requiresWorld() { return false; }

    @Override
    @SuppressWarnings("unchecked")
    protected void onEnable() {
        OptionInstance<Double> opt = mc.options.gamma();
        previous = opt.get();
        apply();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void onDisable() {
        if (mc.options == null) return;
        ((AccessorOptionInstance<Double>) (Object) mc.options.gamma()).iceclient$setValue(Math.min(1.0, previous));
    }

    @Override
    public void onTick() { apply(); }

    @SuppressWarnings("unchecked")
    private void apply() {
        OptionInstance<Double> opt = mc.options.gamma();
        if (Math.abs(opt.get() - gamma.d()) > 0.001) {
            ((AccessorOptionInstance<Double>) (Object) opt).iceclient$setValue(gamma.d());
        }
    }
}
