package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;

/** Progress bar for eating / drinking food items. */
public final class EatTimer extends Module {
    private final NumberSetting eatTicks = add(new NumberSetting("EatTicks", "Ticks a food item takes to consume", 32, 8, 64, 1));
    private final NumberSetting yOffset = add(new NumberSetting("Y", "Offset above the hotbar", 60, 20, 200, 1));

    private int usingTicks;

    public EatTimer() {
        super("EatTimer", "Thanh tien trinh khi an.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        usingTicks = (mc.player.isUsingItem() && holdingFood()) ? usingTicks + 1 : 0;
    }

    private boolean holdingFood() {
        ItemStack main = mc.player.getMainHandItem();
        ItemStack off = mc.player.getOffhandItem();
        return main.has(DataComponents.FOOD) || off.has(DataComponents.FOOD);
    }

    @Override
    public void onRender2D(GuiGraphics g) {
        if (usingTicks <= 0) return;
        float progress = Math.min(1f, usingTicks / eatTicks.f());
        int w = 80, h = 8;
        int x = (g.guiWidth() - w) / 2;
        int y = g.guiHeight() - yOffset.i();
        Render2D.panel(g, x - 1, y - 1, w + 2, h + 2, Theme.alpha(Theme.BG, 0xD0), Theme.BORDER);
        Render2D.rect(g, x, y, (int) (w * progress), h, Theme.PRIMARY);
        String s = String.format("%.1fs", Math.max(0f, (eatTicks.f() - usingTicks)) / 20f);
        Render2D.shadowText(g, s, x + (w - Render2D.width(s)) / 2, y - 11, Theme.TEXT);
    }
}
