package com.iceclient.module.combat;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Mainhand — giữ totem ở hotbar slot chỉ định (1-9).
 * Tự động refill totem từ inventory vào hotbar slot target.
 * Tương tự Night's MainhandModule nhưng stripped down cho iceclient API.
 */
public final class Mainhand extends Module {

    private final NumberSetting slot = add(new NumberSetting(
            "Slot",
            "Hotbar slot giữ totem (1-9).",
            1, 1, 9
    ));

    private final NumberSetting delay = add(new NumberSetting(
            "Delay",
            "Delay ticks giữa các lần refill.",
            3, 1, 20
    ));

    private final BooleanSetting elytraCheck = add(new BooleanSetting(
            "ElytraCheck",
            "Ưu tiên totem khi đang mặc elytra.",
            true
    ));

    private static final int HOTBAR_BASE = 36;
    private int cooldown = 0;

    public Mainhand() {
        super("Mainhand", "Giữ totem ở hotbar slot chỉ định.", Category.COMBAT);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!isEnabled()) return;
            if (client.player == null || client.level == null) return;
            if (cooldown > 0) { cooldown--; return; }
            tick(client.player);
        });
    }

    private void tick(LocalPlayer player) {
        int targetIdx = (int) slot.getFloat() - 1; // 1-9 → 0-8
        Inventory inv = player.getInventory();

        // slot target đã có totem chưa?
        if (inv.getItem(targetIdx).getItem() == Items.TOTEM_OF_UNDYING) return;

        // elytra check
        if (elytraCheck.get()) {
            var chest = player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST);
            if (chest.getItem() != net.minecraft.world.item.Items.ELYTRA) {
                // không mặc elytra, bỏ qua nếu HP đủ cao
                float hp = player.getHealth() + player.getAbsorptionAmount();
                if (hp > 20f) return;
            }
        }

        // tìm totem trong inventory (ưu tiên main inv, skip target slot)
        int src = findTotem(player, targetIdx);
        if (src < 0) return;

        int menuId = player.inventoryMenu.containerId;
        if (mc.screen == null) mc.player.openInventory();

        int srcContainer  = src < 9 ? HOTBAR_BASE + src : src;
        int destContainer = HOTBAR_BASE + targetIdx;

        // pickup src → cursor
        mc.gameMode.handleInventoryMouseClick(menuId, srcContainer, 0, ClickType.PICKUP, player);
        // swap cursor ↔ target slot
        mc.gameMode.handleInventoryMouseClick(menuId, destContainer, 0, ClickType.PICKUP, player);
        // nếu target không rỗng, item cũ ra cursor → đặt về src
        if (!inv.getItem(targetIdx).isEmpty()) {
            mc.gameMode.handleInventoryMouseClick(menuId, srcContainer, 0, ClickType.PICKUP, player);
        }

        cooldown = (int) delay.getFloat();
    }

    private int findTotem(LocalPlayer player, int skip) {
        Inventory inv = player.getInventory();
        for (int i = 9; i < 36; i++) {
            if (i != skip && inv.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (i != skip && inv.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        return -1;
    }
}
