package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.StringSetting;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;

import java.util.UUID;

/** Spawns a client-side copy of you, handy for testing combat modules. */
public final class FakePlayer extends Module {
    private final StringSetting fakeName = add(new StringSetting("Name", "Name of the fake player", "IceDummy"));
    private static final int FAKE_ID = -48151;

    private RemotePlayer fake;
    private ClientLevel spawnedIn;

    public FakePlayer() {
        super("FakePlayer", "Tao nguoi choi gia (chi client) de thu module.", Category.MISC);
    }

    @Override
    protected void onEnable() {
        LocalPlayer p = mc.player;
        fake = new RemotePlayer(mc.level, new GameProfile(UUID.randomUUID(), fakeName.get().isBlank() ? "IceDummy" : fakeName.get()));
        fake.setId(FAKE_ID);
        fake.getInventory().replaceWith(p.getInventory());
        for (EquipmentSlot slot : EquipmentSlot.values()) fake.setItemSlot(slot, p.getItemBySlot(slot).copy());
        fake.setPos(p.getX(), p.getY(), p.getZ());
        fake.setYRot(p.getYRot());
        fake.setXRot(p.getXRot());
        fake.setYHeadRot(p.getYHeadRot());
        fake.setPose(p.getPose());
        fake.setOnGround(p.onGround());
        mc.level.addEntity(fake);
        spawnedIn = mc.level;
    }

    @Override
    protected void onDisable() {
        if (fake != null && !fake.isRemoved()) fake.remove(Entity.RemovalReason.DISCARDED);
        fake = null;
        spawnedIn = null;
    }

    @Override
    public void onTick() {
        // World changed (disconnect / dimension switch): drop the dummy.
        if (mc.level != spawnedIn || fake == null || fake.isRemoved()) setEnabled(false);
    }
}
