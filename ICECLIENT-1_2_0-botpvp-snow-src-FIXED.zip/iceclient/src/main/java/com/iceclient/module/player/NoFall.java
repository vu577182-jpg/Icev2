package com.iceclient.module.player;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

public final class NoFall extends Module {
    private final NumberSetting distance = add(new NumberSetting("Distance", "Fall distance before the on-ground packet is sent", 2.5, 1, 10, 0.5));

    public NoFall() {
        super("NoFall", "Giam sat thuong roi bang goi tin on-ground.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p.getAbilities().flying || p.isFallFlying()) return;
        if (!p.onGround() && p.fallDistance > distance.d() && mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundMovePlayerPacket.StatusOnly(true, p.horizontalCollision));
        }
    }
}
