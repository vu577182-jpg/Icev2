package com.iceclient.module.player;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;

/**
 * Simplified AutoShop for common PvP shop layouts.
 * Inspired by Night AutoShopModule — slot indices are configurable
 * because each server uses different shop GUIs.
 *
 * Default slots match a common "set 1 / confirm" layout:
 *  item buttons around 10-20, quantity +/- around 20-30, confirm near bottom.
 * Adjust the Number settings to match your server.
 */
public final class AutoShop extends Module {
    // What to buy (stacks / counts)
    public final NumberSetting totemAmount = add(new NumberSetting("Totems", "How many totems to buy", 1, 0, 64));
    public final NumberSetting crystalStacks = add(new NumberSetting("CrystalStacks", "Stacks of end crystals", 4, 0, 64));
    public final NumberSetting expStacks = add(new NumberSetting("ExpStacks", "Stacks of exp bottles", 4, 0, 64));
    public final NumberSetting obsidianStacks = add(new NumberSetting("ObsidianStacks", "Stacks of obsidian", 2, 0, 64));
    public final NumberSetting pearlStacks = add(new NumberSetting("PearlStacks", "Stacks of ender pearls", 1, 0, 16));

    // Shop slot indices (server-dependent — tweak these)
    public final NumberSetting slotTotem = add(new NumberSetting("SlotTotem", "Container slot for totem button", 10, 0, 53));
    public final NumberSetting slotCrystal = add(new NumberSetting("SlotCrystal", "Container slot for crystal button", 11, 0, 53));
    public final NumberSetting slotExp = add(new NumberSetting("SlotExp", "Container slot for exp button", 12, 0, 53));
    public final NumberSetting slotObsidian = add(new NumberSetting("SlotObsidian", "Container slot for obsidian button", 13, 0, 53));
    public final NumberSetting slotPearl = add(new NumberSetting("SlotPearl", "Container slot for pearl button", 14, 0, 53));
    public final NumberSetting slotConfirm = add(new NumberSetting("SlotConfirm", "Container slot for confirm/buy button", 31, 0, 53));

    public final NumberSetting actionDelay = add(new NumberSetting("Delay", "Ticks between shop clicks", 3, 1, 20));
    public final BooleanSetting closeWhenDone = add(new BooleanSetting("CloseWhenDone", "Close the shop when finished", true));

    private enum State { IDLE, OPEN_ITEM, CONFIRM, NEXT, DONE }
    private State state = State.IDLE;
    private int ticks;
    private int step; // which item in the plan
    private int[] planAmounts;
    private int[] planSlots;

    public AutoShop() {
        super("AutoShop", "Auto-buy common PvP items from an open shop GUI.", Category.PLAYER);
    }

    @Override
    protected void onEnable() {
        rebuildPlan();
        state = State.IDLE;
        ticks = 0;
        step = 0;
    }

    @Override
    protected void onDisable() {
        state = State.IDLE;
    }

    private void rebuildPlan() {
        // Build a compact list of (slot, amount) pairs that are > 0
        int[] slots = {
            slotTotem.getInt(), slotCrystal.getInt(), slotExp.getInt(),
            slotObsidian.getInt(), slotPearl.getInt()
        };
        int[] amounts = {
            totemAmount.getInt(), crystalStacks.getInt(), expStacks.getInt(),
            obsidianStacks.getInt(), pearlStacks.getInt()
        };
        int n = 0;
        for (int a : amounts) if (a > 0) n++;
        planSlots = new int[n];
        planAmounts = new int[n];
        int j = 0;
        for (int i = 0; i < amounts.length; i++) {
            if (amounts[i] <= 0) continue;
            planSlots[j] = slots[i];
            planAmounts[j] = amounts[i];
            j++;
        }
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;

        Screen screen = mc.screen;
        if (!(screen instanceof AbstractContainerScreen<?> container)) {
            // Wait until player opens a shop
            state = State.IDLE;
            ticks = 0;
            return;
        }

        if (planSlots == null || planSlots.length == 0) {
            rebuildPlan();
            if (planSlots.length == 0) {
                setEnabled(false);
                return;
            }
        }

        if (ticks > 0) { ticks--; return; }

        int syncId = container.getMenu().containerId;

        switch (state) {
            case IDLE -> {
                step = 0;
                state = State.OPEN_ITEM;
            }
            case OPEN_ITEM -> {
                if (step >= planSlots.length) {
                    state = State.DONE;
                    break;
                }
                // Click the item button in the shop
                click(mc, syncId, planSlots[step]);
                ticks = actionDelay.getInt();
                state = State.CONFIRM;
            }
            case CONFIRM -> {
                // Click confirm / buy
                click(mc, syncId, slotConfirm.getInt());
                ticks = actionDelay.getInt();
                // For multi-stack items we may need to confirm multiple times
                planAmounts[step]--;
                if (planAmounts[step] > 0) {
                    state = State.OPEN_ITEM; // buy another of same item
                } else {
                    state = State.NEXT;
                }
            }
            case NEXT -> {
                step++;
                state = step >= planSlots.length ? State.DONE : State.OPEN_ITEM;
                ticks = actionDelay.getInt();
            }
            case DONE -> {
                if (closeWhenDone.on()) {
                    mc.player.closeContainer();
                }
                setEnabled(false);
            }
        }
    }

    private void click(Minecraft mc, int syncId, int slot) {
        try {
            mc.gameMode.handleInventoryMouseClick(syncId, slot, 0, ClickType.PICKUP, mc.player);
        } catch (Throwable t) {
            fail("shop-click", t);
        }
    }

    @Override
    public String info() {
        return state == State.IDLE ? "wait" : state.name().toLowerCase() + " " + step + "/" + (planSlots == null ? 0 : planSlots.length);
    }
}
