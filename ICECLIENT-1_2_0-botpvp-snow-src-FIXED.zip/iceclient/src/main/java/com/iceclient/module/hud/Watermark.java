package com.iceclient.module.hud;

import com.iceclient.client.Ice;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphics;

public final class Watermark extends Module {
    private final NumberSetting x = add(new NumberSetting("X", "Horizontal offset", 6, 0, 600, 1));
    private final NumberSetting y = add(new NumberSetting("Y", "Vertical offset", 6, 0, 400, 1));

    public Watermark() {
        super("Watermark", "Hien thi ten client tren man hinh.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }

    @Override
    public void onRender2D(GuiGraphics g) {
        String title = Ice.NAME;
        String version = Ice.VERSION;
        int w = Render2D.width(title) + Render2D.width(version) + 22;
        int px = x.i(), py = y.i();
        Render2D.panel(g, px, py, w, 16, Theme.alpha(Theme.BG, 0xD0), Theme.BORDER);
        Render2D.rect(g, px + 1, py + 1, 2, 14, Theme.PRIMARY);
        Render2D.shadowText(g, title, px + 8, py + 4, Theme.PRIMARY);
        Render2D.text(g, version, px + 12 + Render2D.width(title), py + 4, Theme.MUTED);
    }
}
