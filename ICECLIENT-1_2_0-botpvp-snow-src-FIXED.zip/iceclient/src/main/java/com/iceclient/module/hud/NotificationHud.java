package com.iceclient.module.hud;

import com.iceclient.module.Category;
import com.iceclient.module.Module;

/** Marker module: while enabled, {@link com.iceclient.manager.NotificationManager} draws its toasts. */
public final class NotificationHud extends Module {
    public NotificationHud() {
        super("Notification", "Hien thong bao bat/tat module va canh bao.", Category.HUD);
        setEnabledSilently(true);
    }

    @Override protected boolean requiresWorld() { return false; }
}
