package com.iceclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.iceclient.client.Ice;
import com.iceclient.module.Module;
import com.iceclient.module.ModuleManager;
import com.iceclient.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

/** JSON configs stored in {@code <minecraft>/config/iceclient/<name>.json}. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {}

    private static Path dir() throws IOException {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("iceclient");
        Files.createDirectories(d);
        return d;
    }

    private static String clean(String name) { return name.replaceAll("[^A-Za-z0-9_-]", ""); }

    public static boolean save(String name) {
        name = clean(name);
        if (name.isEmpty()) return false;
        try (Writer w = Files.newBufferedWriter(dir().resolve(name + ".json"), StandardCharsets.UTF_8)) {
            JsonObject root = new JsonObject();
            JsonObject modules = new JsonObject();
            for (Module m : ModuleManager.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.getKey());
                JsonObject settings = new JsonObject();
                for (Setting<?> s : m.settings) settings.add(s.name, s.save());
                o.add("settings", settings);
                modules.add(m.name, o);
            }
            root.addProperty("client", Ice.NAME);
            root.addProperty("version", Ice.VERSION);
            root.add("modules", modules);
            GSON.toJson(root, w);
            return true;
        } catch (Throwable t) {
            Ice.LOGGER.error("Failed to save config {}", name, t);
            return false;
        }
    }

    public static boolean load(String name) {
        name = clean(name);
        if (name.isEmpty()) return false;
        try {
            Path file = dir().resolve(name + ".json");
            if (!Files.exists(file)) return false;
            JsonObject root;
            try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                root = JsonParser.parseReader(r).getAsJsonObject();
            }
            JsonObject modules = root.getAsJsonObject("modules");
            if (modules == null) return false;
            for (Module m : ModuleManager.all()) {
                JsonElement e = modules.get(m.name);
                if (e == null || !e.isJsonObject()) continue;
                JsonObject o = e.getAsJsonObject();
                try {
                    if (o.has("key")) m.setKey(o.get("key").getAsInt());
                    if (o.has("settings") && o.get("settings").isJsonObject()) {
                        JsonObject so = o.getAsJsonObject("settings");
                        for (Setting<?> s : m.settings) if (so.has(s.name)) s.load(so.get(s.name));
                    }
                    if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
                } catch (Throwable t) {
                    Ice.LOGGER.warn("Skipping bad config entry for {}", m.name, t);
                }
            }
            return true;
        } catch (Throwable t) {
            Ice.LOGGER.error("Failed to load config {}", name, t);
            return false;
        }
    }

    public static boolean delete(String name) {
        try {
            return Files.deleteIfExists(dir().resolve(clean(name) + ".json"));
        } catch (IOException e) {
            Ice.LOGGER.error("Failed to delete config {}", name, e);
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".json"))
                    .forEach(n -> out.add(n.substring(0, n.length() - 5)));
        } catch (IOException e) {
            Ice.LOGGER.error("Failed to list configs", e);
        }
        Collections.sort(out);
        return out;
    }
}
