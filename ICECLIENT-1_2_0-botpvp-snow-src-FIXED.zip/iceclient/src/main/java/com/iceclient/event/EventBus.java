package com.iceclient.event;

import com.iceclient.client.Ice;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Minimal thread-safe event bus (packets arrive on the netty thread). */
public final class EventBus {
    private final Map<Class<?>, List<Consumer<Object>>> handlers = new ConcurrentHashMap<>();

    @SuppressWarnings("unchecked")
    public <T extends Event> Consumer<T> subscribe(Class<T> type, Consumer<T> handler) {
        handlers.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>()).add((Consumer<Object>) (Consumer<?>) handler);
        return handler;
    }

    public <T extends Event> void unsubscribe(Class<T> type, Consumer<T> handler) {
        List<Consumer<Object>> list = handlers.get(type);
        if (list != null) list.remove(handler);
    }

    public <T extends Event> T post(T event) {
        List<Consumer<Object>> list = handlers.get(event.getClass());
        if (list == null) return event;
        for (Consumer<Object> h : list) {
            try {
                h.accept(event);
            } catch (Throwable t) {
                Ice.LOGGER.error("Event handler failed for {}", event.getClass().getSimpleName(), t);
            }
        }
        return event;
    }
}
