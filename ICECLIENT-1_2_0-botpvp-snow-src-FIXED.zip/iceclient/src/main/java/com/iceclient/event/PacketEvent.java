package com.iceclient.event;

import net.minecraft.network.protocol.Packet;

public class PacketEvent extends Event {
    public final Packet<?> packet;

    protected PacketEvent(Packet<?> packet) { this.packet = packet; }

    /** Fired for every clientbound packet before the game handles it. */
    public static final class Receive extends PacketEvent {
        public Receive(Packet<?> packet) { super(packet); }
    }
}
