package com.iceclient.gui;

import com.iceclient.config.ConfigManager;
import com.iceclient.manager.NotificationManager;
import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.module.ModuleManager;
import com.iceclient.module.client.ClickGui;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.ModeSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.setting.Setting;
import com.iceclient.setting.StringSetting;
import com.iceclient.util.Animation;
import com.iceclient.util.KeyUtil;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** ICE PRO click GUI: header with logo + search, left sidebar, scrollable module cards, config manager. */
public final class IceScreen extends Screen {
    private static final int MAX_W = 580, MAX_H = 372, HEADER = 46, SIDE = 128, CARD_H = 34, ROW = 22, NUM_ROW = 28;

    // ---- immediate-mode hit regions ----------------------------------------
    private interface Click { void on(int button, int mouseX); }
    private interface Drag { void on(int mouseX); }
    private interface TextTarget { String get(); void set(String s); }

    private record Hit(int x, int y, int w, int h, Click click, Drag drag) {
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private record Tab(String label, Category category) {}

    private final Minecraft game = Minecraft.getInstance();
    private final List<Hit> hits = new ArrayList<>();
    private final List<Tab> tabs = new ArrayList<>();
    private final Map<String, Animation> tabAnim = new java.util.HashMap<>();
    private final Map<Setting<?>, Animation> boolAnim = new IdentityHashMap<>();
    private final Animation scroll = new Animation(0f, 16f);

    private Hit dragging;
    private Category category = Category.COMBAT;
    private boolean configTab;
    private String search = "";
    private String configName = "";
    private String selectedConfig;
    private TextTarget focus;
    private Module listening;
    private float scrollTarget;
    private int contentHeight;

    // layout (recomputed every frame)
    private int fw, fh, x0, y0, cx, cy, cw, ch;

    private final TextTarget searchTarget = new TextTarget() {
        @Override public String get() { return search; }
        @Override public void set(String s) { search = s; scrollTarget = 0; configTab = false; }
    };
    private final TextTarget configTarget = new TextTarget() {
        @Override public String get() { return configName; }
        @Override public void set(String s) { configName = s.replaceAll("[^A-Za-z0-9_-]", ""); }
    };

    public IceScreen() {
        super(Component.literal("ICECLIENT"));
        for (Category c : Category.values()) tabs.add(new Tab(c.label, c));
        tabs.add(new Tab("Configs", null));
    }

    @Override public boolean isPauseScreen() { return false; }

    // ======================================================================
    // rendering
    // ======================================================================
    @Override
    public void extractBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        ClickGui cg = ModuleManager.get(ClickGui.class);
        if (cg == null || cg.dim.on()) g.fill(0, 0, g.guiWidth(), g.guiHeight(), 0x99020509);
    }

    @Override
    public void extractRenderState(GuiGraphics g, int mx, int my, float partialTick) {
        hits.clear();
        int sw = g.guiWidth(), sh = g.guiHeight();
        fw = Math.min(MAX_W, sw - 16);
        fh = Math.min(MAX_H, sh - 16);
        x0 = (sw - fw) / 2;
        y0 = (sh - fh) / 2;
        cx = x0 + SIDE + 12;
        cy = y0 + HEADER + 12;
        cw = fw - SIDE - 24;
        ch = fh - HEADER - 24;

        // frame
        Render2D.panel(g, x0 - 1, y0 - 1, fw + 2, fh + 2, Theme.BG, Theme.BORDER);
        g.fillGradient(x0, y0, x0 + fw, y0 + fh, 0xFF0A1424, 0xFF050910);

        drawHeader(g, mx, my);
        drawSidebar(g, mx, my);
        if (configTab) drawConfigs(g, mx, my); else drawModules(g, mx, my);
        drawIce(g);
        drawSnowflakes(g);
    }

    private void drawHeader(GuiGraphics g, int mx, int my) {
        g.fillGradient(x0, y0, x0 + fw, y0 + HEADER, 0xFF0E1A30, 0xFF081018);
        Render2D.rect(g, x0, y0 + HEADER, fw, 1, Theme.BORDER);
        Render2D.rect(g, x0 + fw / 2 - 70, y0 + HEADER, 140, 1, Theme.alpha(Theme.PRIMARY, 0xC0));

        String logo = "ICECLIENT";
        int spacing = 3, total = 0;
        for (char c : logo.toCharArray()) total += Render2D.width(String.valueOf(c)) + spacing;
        total -= spacing;
        int lx = x0 + (fw - total) / 2, ly = y0 + (HEADER - 9) / 2 - 1;
        for (int i = 0; i < logo.length(); i++) {
            String s = String.valueOf(logo.charAt(i));
            int col = Theme.lerp(Theme.SECONDARY, Theme.PRIMARY, i / (float) (logo.length() - 1));
            Render2D.text(g, s, lx + 1, ly + 1, Theme.alpha(Theme.PRIMARY, 0x55));
            Render2D.text(g, s, lx, ly, col);
            lx += Render2D.width(s) + spacing;
        }

        Render2D.text(g, "ICE PRO", x0 + 14, y0 + (HEADER - 9) / 2, Theme.MUTED);

        // search box
        int sx = x0 + fw - 166, sy = y0 + 12, sww = 152, shh = 22;
        boolean focused = focus == searchTarget;
        Render2D.panel(g, sx, sy, sww, shh, Theme.CARD, focused ? Theme.PRIMARY : Theme.BORDER);
        String shown = search.isEmpty() && !focused ? "Search modules..." : fit(search, sww - 16, true) + caret(focused);
        Render2D.text(g, shown, sx + 8, sy + 7, search.isEmpty() && !focused ? Theme.MUTED : Theme.TEXT);
        hit(sx, sy, sww, shh, false, (b, m) -> focus = searchTarget, null);
    }

    private void drawSidebar(GuiGraphics g, int mx, int my) {
        Render2D.rect(g, x0, y0 + HEADER + 1, SIDE, fh - HEADER - 1, Theme.alpha(Theme.BG_LIGHT, 0xFF));
        Render2D.rect(g, x0 + SIDE, y0 + HEADER + 1, 1, fh - HEADER - 1, Theme.BORDER);

        int y = y0 + HEADER + 14;
        for (Tab tab : tabs) {
            boolean selected = tab.category() == null ? configTab : (!configTab && category == tab.category() && search.isEmpty());
            Animation a = tabAnim.computeIfAbsent(tab.label(), k -> new Animation(0f));
            a.set(selected ? 1f : 0f);
            float t = a.get();
            boolean hover = mx >= x0 && mx < x0 + SIDE && my >= y && my < y + 26;
            int bg = Theme.lerp(hover ? Theme.alpha(Theme.PRIMARY, 0x14) : 0x00000000, Theme.alpha(Theme.PRIMARY, 0x30), t);
            Render2D.rect(g, x0 + 8, y, SIDE - 16, 26, bg);
            Render2D.rect(g, x0 + 8, y + 3, 3, (int) (20 * t), Theme.PRIMARY);
            Render2D.text(g, tab.label(), x0 + 20, y + 9, Theme.lerp(Theme.MUTED, Theme.TEXT, Math.max(t, hover ? 0.6f : 0f)));
            if (tab.category() != null) {
                int count = 0;
                for (Module m : ModuleManager.byCategory(tab.category())) if (!m.isHidden()) count++;
                String n = String.valueOf(count);
                Render2D.text(g, n, x0 + SIDE - 18 - Render2D.width(n) + 6, y + 9, Theme.alpha(Theme.SECONDARY, 0x90));
            }
            final Tab clicked = tab;
            hit(x0 + 8, y, SIDE - 16, 26, false, (b, m) -> {
                configTab = clicked.category() == null;
                if (clicked.category() != null) category = clicked.category();
                search = "";
                scrollTarget = 0;
                focus = null;
            }, null);
            y += 30;
        }
        Render2D.text(g, "v" + com.iceclient.client.Ice.VERSION, x0 + 14, y0 + fh - 14, Theme.alpha(Theme.MUTED, 0xA0));
    }

    // ---- module list ------------------------------------------------------
    private void drawModules(GuiGraphics g, int mx, int my) {
        List<Module> list = new ArrayList<>();
        if (search.isEmpty()) {
            for (Module m : ModuleManager.byCategory(category)) {
                if (!m.isHidden()) list.add(m);
            }
        } else {
            String q = search.toLowerCase(Locale.ROOT);
            for (Module m : ModuleManager.all()) {
                if (m.isHidden()) continue;
                if (m.name.toLowerCase(Locale.ROOT).contains(q) || m.description.toLowerCase(Locale.ROOT).contains(q)) list.add(m);
            }
        }

        float maxScroll = Math.max(0, contentHeight - ch);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll.set(scrollTarget);
        int offset = Math.round(scroll.get());

        g.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        int y = cy - offset;
        if (list.isEmpty()) Render2D.text(g, "Khong co module nao.", cx + 4, cy + 4, Theme.MUTED);
        for (Module m : list) y += drawCard(g, m, cx, y, cw, mx, my) + 6;
        contentHeight = y - (cy - offset);
        g.disableScissor();

        if (contentHeight > ch) {
            int barH = Math.max(18, (int) (ch * (ch / (float) contentHeight)));
            int barY = cy + (int) ((ch - barH) * (scroll.get() / Math.max(1f, contentHeight - ch)));
            Render2D.rect(g, cx + cw + 3, cy, 2, ch, Theme.alpha(Theme.BORDER, 0x80));
            Render2D.rect(g, cx + cw + 3, barY, 2, barH, Theme.PRIMARY);
        }
    }

    private int extraHeight(Module m) {
        int h = 6 + ROW;
        for (Setting<?> s : m.settings) if (s.isVisible()) h += rowHeight(s);
        return h + 4;
    }

    private int rowHeight(Setting<?> s) { return s instanceof NumberSetting ? NUM_ROW : ROW; }

    private int drawCard(GuiGraphics g, Module m, int x, int y, int w, int mx, int my) {
        m.guiExpand.set(m.guiExpanded ? 1f : 0f);
        m.guiToggle.set(m.isEnabled() ? 1f : 0f);
        float ex = m.guiExpand.get();
        float tg = m.guiToggle.get();
        int h = CARD_H + Math.round(extraHeight(m) * ex);

        boolean inView = y + h >= cy && y <= cy + ch;
        if (!inView) return h;

        boolean hover = mx >= x && mx < x + w && my >= y && my < y + CARD_H && my >= cy && my < cy + ch;
        int border = Theme.lerp(Theme.BORDER, Theme.alpha(Theme.PRIMARY, 0xA0), tg);
        Render2D.panel(g, x, y, w, h, hover ? Theme.CARD_HOVER : Theme.CARD, border);
        Render2D.rect(g, x + 1, y + 4, 3, (int) ((CARD_H - 8) * tg), Theme.PRIMARY);

        Render2D.text(g, m.name, x + 12, y + 7, Theme.lerp(Theme.SECONDARY, Theme.TEXT, tg));
        Render2D.text(g, Render2D.trim(m.description, w - 190), x + 12, y + 19, Theme.MUTED);

        // key chip
        String key = KeyUtil.name(m.getKey());
        if (m.getKey() >= 0) Render2D.text(g, "[" + key + "]", x + w - 52 - Render2D.width("[" + key + "]") - 14, y + 13, Theme.alpha(Theme.SECONDARY, 0xA0));
        Render2D.text(g, m.guiExpanded ? "v" : ">", x + w - 62, y + 13, Theme.MUTED);
        drawSwitch(g, x + w - 46, y + 9, 34, 16, tg);

        hit(x, y, w, CARD_H, true, (b, mouse) -> {
            if (b == 0) m.toggle();
            else if (b == 1) m.guiExpanded = !m.guiExpanded;
        }, null);

        if (ex > 0.02f) {
            int limit = y + h - 2;
            int rx = x + 12, rw = w - 24;
            int ry = y + CARD_H + 4;
            Render2D.rect(g, x + 8, y + CARD_H, w - 16, 1, Theme.alpha(Theme.BORDER, 0xC0));

            if (ry + ROW <= limit) {
                drawKeyRow(g, m, rx, ry, rw);
            }
            ry += ROW;
            for (Setting<?> s : m.settings) {
                if (!s.isVisible()) continue;
                int rh = rowHeight(s);
                if (ry + rh <= limit) drawSetting(g, s, rx, ry, rw);
                ry += rh;
            }
        }
        return h;
    }

    private void drawSwitch(GuiGraphics g, int x, int y, int w, int h, float t) {
        Render2D.panel(g, x, y, w, h, Theme.lerp(Theme.TRACK_OFF, Theme.alpha(Theme.PRIMARY, 0xFF), t), Theme.lerp(Theme.BORDER, Theme.SECONDARY, t));
        int knob = h - 6;
        int kx = x + 3 + Math.round((w - knob - 6) * t);
        Render2D.rect(g, kx, y + 3, knob, knob, Theme.lerp(Theme.MUTED, Theme.TEXT, t));
    }

    private void drawKeyRow(GuiGraphics g, Module m, int x, int y, int w) {
        Render2D.text(g, "Keybind", x, y + 6, Theme.MUTED);
        int bw = 110, bx = x + w - bw;
        boolean active = listening == m;
        Render2D.panel(g, bx, y + 2, bw, 16, Theme.BG, active ? Theme.PRIMARY : Theme.BORDER);
        String t = active ? "Press a key..." : KeyUtil.name(m.getKey());
        Render2D.text(g, t, bx + (bw - Render2D.width(t)) / 2, y + 6, active ? Theme.PRIMARY : Theme.TEXT);
        hit(bx, y + 2, bw, 16, true, (b, mouse) -> {
            if (b == 0) { listening = m; focus = null; }
            else if (b == 1) { m.setKey(-1); listening = null; }
        }, null);
    }

    private void drawSetting(GuiGraphics g, Setting<?> s, int x, int y, int w) {
        if (s instanceof BooleanSetting bs) {
            Animation a = boolAnim.computeIfAbsent(s, k -> new Animation(bs.on() ? 1f : 0f));
            a.set(bs.on() ? 1f : 0f);
            Render2D.text(g, bs.name, x, y + 6, Theme.TEXT);
            drawSwitch(g, x + w - 30, y + 4, 30, 14, a.get());
            hit(x, y, w, ROW, true, (b, m) -> { if (b == 0) bs.toggle(); }, null);
        } else if (s instanceof NumberSetting ns) {
            Render2D.text(g, ns.name, x, y + 3, Theme.TEXT);
            String v = ns.display();
            Render2D.text(g, v, x + w - Render2D.width(v), y + 3, Theme.SECONDARY);
            float t = (float) ((ns.d() - ns.min) / (ns.max - ns.min));
            int by = y + 18;
            Render2D.rect(g, x, by, w, 4, Theme.TRACK_OFF);
            Render2D.rect(g, x, by, (int) (w * t), 4, Theme.PRIMARY);
            int kx = x + (int) (w * t) - 3;
            Render2D.rect(g, kx, by - 2, 6, 8, Theme.TEXT);
            Drag drag = mouse -> ns.set(ns.min + Math.max(0f, Math.min(1f, (mouse - x) / (float) w)) * (ns.max - ns.min));
            hit(x - 3, y + 12, w + 6, 16, true, (b, mouse) -> { if (b == 0) drag.on(mouse); }, drag);
        } else if (s instanceof ModeSetting ms) {
            Render2D.text(g, ms.name, x, y + 6, Theme.TEXT);
            int bw = 110, bx = x + w - bw;
            Render2D.panel(g, bx, y + 2, bw, 16, Theme.BG, Theme.BORDER);
            Render2D.text(g, ms.get(), bx + (bw - Render2D.width(ms.get())) / 2, y + 6, Theme.SECONDARY);
            hit(bx, y + 2, bw, 16, true, (b, m) -> { if (b == 0) ms.cycle(1); else if (b == 1) ms.cycle(-1); }, null);
        } else if (s instanceof StringSetting ss) {
            Render2D.text(g, ss.name, x, y + 6, Theme.TEXT);
            int bw = Math.min(190, w - 90), bx = x + w - bw;
            TextTarget target = new TextTarget() {
                @Override public String get() { return ss.get(); }
                @Override public void set(String v) { ss.set(v); }
            };
            boolean f = focus instanceof StringTarget st && st.setting == ss;
            Render2D.panel(g, bx, y + 2, bw, 16, Theme.BG, f ? Theme.PRIMARY : Theme.BORDER);
            Render2D.text(g, fit(ss.get(), bw - 12, true) + caret(f), bx + 6, y + 6, Theme.TEXT);
            hit(bx, y + 2, bw, 16, true, (b, m) -> focus = new StringTarget(ss, target), null);
        }
    }

    /** TextTarget bound to a StringSetting so we can detect which field is focused. */
    private static final class StringTarget implements TextTarget {
        final StringSetting setting;
        private final TextTarget delegate;
        StringTarget(StringSetting setting, TextTarget delegate) { this.setting = setting; this.delegate = delegate; }
        @Override public String get() { return delegate.get(); }
        @Override public void set(String s) { delegate.set(s); }
    }

    // ---- config manager -----------------------------------------------------
    private void drawConfigs(GuiGraphics g, int mx, int my) {
        Render2D.text(g, "Config Manager", cx, cy, Theme.SECONDARY);
        Render2D.text(g, "Luu / nap toan bo module va setting.", cx, cy + 12, Theme.MUTED);

        int ix = cx, iy = cy + 28, iw = Math.min(240, cw), ih = 22;
        boolean f = focus == configTarget;
        Render2D.panel(g, ix, iy, iw, ih, Theme.CARD, f ? Theme.PRIMARY : Theme.BORDER);
        String shown = configName.isEmpty() && !f ? "ten-config" : configName + caret(f);
        Render2D.text(g, shown, ix + 8, iy + 7, configName.isEmpty() && !f ? Theme.MUTED : Theme.TEXT);
        hit(ix, iy, iw, ih, false, (b, m) -> focus = configTarget, null);

        int by = iy + 32;
        button(g, cx, by, 70, 20, "Save", mx, my, (b, m) -> {
            String name = !configName.isBlank() ? configName : selectedConfig;
            if (name == null || name.isBlank()) { NotificationManager.warn("Config", "Nhap ten config"); return; }
            if (ConfigManager.save(name)) { selectedConfig = name; NotificationManager.push("Config", "Da luu " + name, NotificationManager.Type.OK); }
            else NotificationManager.error("Config", "Luu that bai");
        });
        button(g, cx + 78, by, 70, 20, "Load", mx, my, (b, m) -> {
            String name = selectedConfig != null ? selectedConfig : configName;
            if (name == null || name.isBlank()) { NotificationManager.warn("Config", "Chon config de nap"); return; }
            if (ConfigManager.load(name)) NotificationManager.push("Config", "Da nap " + name, NotificationManager.Type.OK);
            else NotificationManager.error("Config", "Khong tim thay " + name);
        });
        button(g, cx + 156, by, 70, 20, "Delete", mx, my, (b, m) -> {
            String name = selectedConfig;
            if (name == null) { NotificationManager.warn("Config", "Chon config de xoa"); return; }
            if (ConfigManager.delete(name)) { NotificationManager.info("Config", "Da xoa " + name); selectedConfig = null; }
            else NotificationManager.error("Config", "Xoa that bai");
        });

        int ly = by + 32;
        Render2D.text(g, "Saved configs", cx, ly - 12, Theme.MUTED);
        int maxRows = Math.max(1, (cy + ch - ly) / 24);
        List<String> names = ConfigManager.list();
        for (int i = 0; i < Math.min(maxRows, names.size()); i++) {
            String n = names.get(i);
            int ry = ly + i * 24;
            boolean sel = n.equals(selectedConfig);
            boolean hover = mx >= cx && mx < cx + cw && my >= ry && my < ry + 22;
            Render2D.panel(g, cx, ry, cw, 22, hover ? Theme.CARD_HOVER : Theme.CARD, sel ? Theme.PRIMARY : Theme.BORDER);
            Render2D.text(g, n, cx + 10, ry + 7, sel ? Theme.TEXT : Theme.SECONDARY);
            hit(cx, ry, cw, 22, false, (b, m) -> { selectedConfig = n; configName = n; }, null);
        }
        if (names.isEmpty()) Render2D.text(g, "Chua co config nao.", cx, ly + 4, Theme.MUTED);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, int mx, int my, Click click) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        Render2D.panel(g, x, y, w, h, hover ? Theme.alpha(Theme.PRIMARY, 0x40) : Theme.CARD, hover ? Theme.PRIMARY : Theme.BORDER);
        Render2D.text(g, label, x + (w - Render2D.width(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hit(x, y, w, h, false, click, null);
    }

    // ---- ice crystals: drawn only inside the menu frame -----------------------
    private static final int[][] CRYSTALS = {
            {8, 14, 3, 11}, {17, 9, 2, 7}, {6, 30, 2, 7}, {24, 24, 2, 5}, {34, 7, 1, 4}, {12, 44, 1, 4}
    };

    private void drawIce(GuiGraphics g) {
        ClickGui cg = ModuleManager.get(ClickGui.class);
        if (cg != null && !cg.ice.on()) return;
        float time = (System.currentTimeMillis() % 100000L) / 1000f;

        // Soft outer frost glow around the frame
        int glowA = 0x18 + (int) (10 * Math.sin(time * 0.9f));
        Render2D.rect(g, x0 - 3, y0 - 3, fw + 6, 2, Theme.alpha(Theme.PRIMARY, glowA));
        Render2D.rect(g, x0 - 3, y0 + fh + 1, fw + 6, 2, Theme.alpha(Theme.PRIMARY, glowA));
        Render2D.rect(g, x0 - 3, y0 - 1, 2, fh + 2, Theme.alpha(Theme.PRIMARY, glowA));
        Render2D.rect(g, x0 + fw + 1, y0 - 1, 2, fh + 2, Theme.alpha(Theme.PRIMARY, glowA));

        // Animated ice crystals in corners
        for (int corner = 0; corner < 4; corner++) {
            boolean right = (corner & 1) == 1, bottom = (corner & 2) == 2;
            for (int i = 0; i < CRYSTALS.length; i++) {
                int[] c = CRYSTALS[i];
                int px = right ? x0 + fw - c[0] : x0 + c[0];
                int py = bottom ? y0 + fh - c[1] : y0 + c[1];
                int alpha = 0x28 + (int) (12 * Math.sin(time * 1.4f + i * 1.7f + corner));
                Render2D.shard(g, px, py, c[2], c[3], alpha);
            }
            // Sparkles
            for (int s = 0; s < 3; s++) {
                double ang = time * (1.1 + s * 0.3) + corner * 1.7 + s;
                int sx = right ? x0 + fw - 10 - s * 6 : x0 + 10 + s * 6;
                int sy = bottom ? y0 + fh - 8 - s * 5 : y0 + 8 + s * 5;
                sx += (int) (3 * Math.sin(ang));
                sy += (int) (2 * Math.cos(ang * 1.3));
                int sa = 0x28 + (int) (20 * Math.sin(time * 2.4f + corner + s));
                g.fill(sx, sy, sx + 1, sy + 1, Theme.alpha(0xE8F8FF, sa));
            }
        }

        // Thin frost line under header
        int lineA = 0x40 + (int) (30 * Math.sin(time * 1.2f));
        Render2D.rect(g, x0 + 20, y0 + HEADER, fw - 40, 1, Theme.alpha(Theme.GLOW, lineA));
    }


    // ======================================================================
    // snowflakes
    // ======================================================================
    private static final int SNOW_N = 32;

    /** Animated snowflakes falling inside the menu frame, clipped to its interior. */
    private void drawSnowflakes(GuiGraphics g) {
        ClickGui cg = ModuleManager.get(ClickGui.class);
        if (cg == null || !cg.snow.on()) return;

        int clipX1 = x0 + 1,  clipY1 = y0 + HEADER + 1;
        int clipX2 = x0 + fw - 1, clipY2 = y0 + fh - 1;
        g.enableScissor(clipX1, clipY1, clipX2, clipY2);

        float time  = (System.currentTimeMillis() % 200_000L) / 1000f;
        int snowW = fw - 2;
        int snowH = fh - HEADER - 2;

        for (int i = 0; i < SNOW_N; i++) {
            float phase    = i * 2.39996f;                      // golden-angle spread
            float speed    = 14f + (phase % 1f) * 18f;          // 14–32 px/sec
            float driftAmp = 2.5f + (phase * 1.3f % 5f);
            float driftSpd = 0.3f + (phase * 0.9f % 0.7f);
            int   sz       = 1 + (i % 3);                       // 1, 2, or 3 px radius

            float relY = (time * speed + (phase % 1f) * snowH) % (snowH + sz * 2 + 4);
            float relX = (phase % 1f) * snowW
                       + driftAmp * (float) Math.sin(time * driftSpd + phase);

            // fade at top / bottom edges
            float fadeIn  = Math.min(1f, relY / 24f);
            float fadeOut = Math.min(1f, (snowH - relY) / 24f);
            float pulse   = 0.28f + 0.22f * (float) Math.sin(time * 1.6f + phase);
            int   alpha   = (int)(Math.max(0f, Math.min(1f, pulse * fadeIn * fadeOut)) * 255f);
            if (alpha < 10) continue;

            int fx = clipX1 + (int) relX;
            int fy = clipY1 + (int) relY;
            if (fx < clipX1 + sz + 1 || fx > clipX2 - sz - 1) continue;

            drawSnowflake(g, fx, fy, sz, Theme.alpha(Theme.SECONDARY, alpha));
        }
        g.disableScissor();
    }

    /**
     * 8-arm pixel snowflake centred on (cx, cy).
     * Arms: horizontal, vertical, and both diagonals.
     */
    private void drawSnowflake(GuiGraphics g, int cx, int cy, int r, int color) {
        // horizontal
        g.fill(cx - r, cy,     cx + r + 1, cy + 1,     color);
        // vertical
        g.fill(cx,     cy - r, cx + 1,     cy + r + 1, color);
        // diagonals (45°)
        for (int d = 1; d <= r; d++) {
            g.fill(cx - d, cy - d, cx - d + 1, cy - d + 1, color); // NW
            g.fill(cx + d, cy - d, cx + d + 1, cy - d + 1, color); // NE
            g.fill(cx - d, cy + d, cx - d + 1, cy + d + 1, color); // SW
            g.fill(cx + d, cy + d, cx + d + 1, cy + d + 1, color); // SE
        }
    }

    // ---- helpers ----------------------------------------------------------------
    private void hit(int x, int y, int w, int h, boolean clipToContent, Click click, Drag drag) {
        if (clipToContent) {
            int top = Math.max(y, cy), bottom = Math.min(y + h, cy + ch);
            if (bottom <= top) return;
            y = top;
            h = bottom - top;
        }
        hits.add(new Hit(x, y, w, h, click, drag));
    }

    private String caret(boolean focused) {
        return focused && (System.currentTimeMillis() / 450) % 2 == 0 ? "_" : "";
    }

    /** Shows the tail of the text so the caret stays visible in narrow fields. */
    private String fit(String s, int maxWidth, boolean tail) {
        if (Render2D.width(s) <= maxWidth) return s;
        while (s.length() > 1 && Render2D.width(s) > maxWidth) s = tail ? s.substring(1) : s.substring(0, s.length() - 1);
        return s;
    }

    // ======================================================================
    // input
    // ======================================================================
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int button = event.button();
        focus = null;
        listening = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (h.drag() != null) dragging = h;
            h.click().on(button, (int) mx);
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging != null && dragging.drag() != null) {
            dragging.drag().on((int) event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget -= (float) (scrollY * 34);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listening != null) {
            // Esc / Backspace / Delete clear the bind
            listening.setKey(key == 256 || key == 259 || key == 261 ? -1 : key);
            listening = null;
            return true;
        }
        if (focus != null) {
            if (key == 256 || key == 257 || key == 335) focus = null;
            else if (key == 259) {
                String s = focus.get();
                if (!s.isEmpty()) focus.set(s.substring(0, s.length() - 1));
            }
            return true;
        }
        if (key == 256) {
            close();
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (focus == null) return false;
        int cp = event.codepoint();
        if (cp < 32 || cp == 127) return false;
        String s = focus.get();
        if (s.length() < 48) focus.set(s + new String(Character.toChars(cp)));
        return true;
    }

    private void close() {
        ConfigManager.save("default");
        game.gui.setScreen(null);
    }
}
