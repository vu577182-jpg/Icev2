package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Lightweight 2D helpers on top of GuiGraphics (MC 26.x). */
public final class Render2D {
    private Render2D() {}

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int color) {
        if (w <= 0 || h <= 0) return;
        g.fill(x, y, x + w, y + h, color);
    }

    public static void hline(GuiGraphics g, int x, int y, int w, int color) {
        if (w <= 0) return;
        g.fill(x, y, x + w, y + 1, color);
    }

    public static void vline(GuiGraphics g, int x, int y, int h, int color) {
        if (h <= 0) return;
        g.fill(x, y, x + 1, y + h, color);
    }

    /** 1px border. */
    public static void border(GuiGraphics g, int x, int y, int w, int h, int color) {
        if (w < 2 || h < 2) return;
        g.fill(x + 1, y, x + w - 1, y + 1, color);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
        g.fill(x, y + 1, x + 1, y + h - 1, color);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    /** Rectangle with 1px chamfered corners (cheap "rounded" look). */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int bg, int border) {
        if (w < 4 || h < 4) { rect(g, x, y, w, h, bg); return; }
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, bg);
        g.fill(x + 1, y, x + w - 1, y + 1, border);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, border);
        g.fill(x, y + 1, x + 1, y + h - 1, border);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, border);
    }

    /** Soft outer glow (multi-layer). */
    public static void glowPanel(GuiGraphics g, int x, int y, int w, int h, int bg, int border, int glowColor) {
        rect(g, x - 2, y - 2, w + 4, 1, Theme.alpha(glowColor, 0x18));
        rect(g, x - 2, y + h + 1, w + 4, 1, Theme.alpha(glowColor, 0x18));
        rect(g, x - 2, y - 1, 1, h + 2, Theme.alpha(glowColor, 0x18));
        rect(g, x + w + 1, y - 1, 1, h + 2, Theme.alpha(glowColor, 0x18));
        panel(g, x, y, w, h, bg, border);
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, false);
    }

    public static void shadowText(GuiGraphics g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, true);
    }

    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static String trim(String s, int maxWidth) {
        if (width(s) <= maxWidth) return s;
        while (s.length() > 1 && width(s + "...") > maxWidth) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    /** Faceted vertical ice shard centred on (cx, cy). */
    public static void shard(GuiGraphics g, int cx, int cy, int hw, int hh, int alpha) {
        int body = Theme.alpha(0x7FD0FF, alpha);
        int facet = Theme.alpha(0xFFFFFF, alpha / 2);
        for (int r = -hh; r <= hh; r++) {
            int w = (int) Math.round(hw * (1.0 - (double) Math.abs(r) / (hh + 1)));
            if (w <= 0) continue;
            g.fill(cx - w, cy + r, cx + w + 1, cy + r + 1, body);
            g.fill(cx - w, cy + r, cx, cy + r + 1, facet);
        }
        g.fill(cx, cy - hh, cx + 1, cy + hh + 1, Theme.alpha(0xFFFFFF, Math.min(255, alpha + 16)));
    }

    /** Soft horizontal frost gradient bar. */
    public static void frostBar(GuiGraphics g, int x, int y, int w, int h, int alpha) {
        if (w <= 0 || h <= 0) return;
        int c0 = Theme.alpha(Theme.PRIMARY, alpha / 3);
        int c1 = Theme.alpha(Theme.GLOW, alpha);
        g.fillGradient(x, y, x + w / 2, y + h, c0, c1);
        g.fillGradient(x + w / 2, y, x + w, y + h, c1, c0);
    }
}
