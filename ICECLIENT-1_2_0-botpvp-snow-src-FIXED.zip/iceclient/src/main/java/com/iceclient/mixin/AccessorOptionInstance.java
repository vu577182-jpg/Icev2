package com.iceclient.mixin;

import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(OptionInstance.class)
public interface AccessorOptionInstance<T> {
    @Accessor("value")
    void iceclient$setValue(T value);
}
