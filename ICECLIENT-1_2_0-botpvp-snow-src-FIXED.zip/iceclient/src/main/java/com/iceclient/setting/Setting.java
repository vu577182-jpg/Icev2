package com.iceclient.setting;

import com.google.gson.JsonElement;

import java.util.function.BooleanSupplier;

public abstract class Setting<T> {
    public final String name;
    public final String description;
    protected T value;
    private final T defaultValue;
    private BooleanSupplier visible = () -> true;

    protected Setting(String name, String description, T value) {
        this.name = name;
        this.description = description;
        this.value = value;
        this.defaultValue = value;
    }

    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public void reset() { this.value = defaultValue; }
    public boolean isVisible() { return visible.getAsBoolean(); }

    @SuppressWarnings("unchecked")
    public <S extends Setting<T>> S visibleWhen(BooleanSupplier supplier) {
        this.visible = supplier;
        return (S) this;
    }

    public abstract JsonElement save();
    public abstract void load(JsonElement element);
}
