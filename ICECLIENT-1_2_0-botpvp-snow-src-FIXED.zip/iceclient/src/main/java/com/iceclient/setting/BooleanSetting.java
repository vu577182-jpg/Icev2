package com.iceclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, String description, boolean value) { super(name, description, value); }

    public boolean on() { return value; }
    public void toggle() { value = !value; }

    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) { if (e != null && e.isJsonPrimitive()) value = e.getAsBoolean(); }
}
