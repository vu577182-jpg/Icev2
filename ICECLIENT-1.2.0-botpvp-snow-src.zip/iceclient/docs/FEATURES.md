# Bang chuc nang (tu phan tich Noxilon 2.2+26.2) va trang thai ICECLIENT

| Nhom | Noxilon | ICECLIENT | Ghi chu |
|---|---|---|---|
| Combat | AutoCrystal | Da viet | Tim nen obsidian/bedrock quanh muc tieu, dat + no crystal, tu doi slot |
| Combat | AutoAnchor | Da viet | Dat -> nap glowstone -> no, chi Overworld/End |
| Combat | AutoPush | Da viet | Piston + redstone block day muc tieu |
| Combat | PistonCrystal | CHUA lam | Logic phuc tap; khong tao module gia |
| Combat | Surround | Da viet | Obsidian quanh chan, support, tu tat khi nhay |
| Combat | Velocity | Da viet | Scale knockback + no explosion (Mixin Connection + accessor) |
| Movement | AutoSprint, AutoWalk | Da viet | |
| Player | NoFall, Replenish | Da viet | |
| Render | FullBright | Da viet | Accessor OptionInstance.value |
| HUD | ArrayList, Coordinates, Watermark, EatTimer, Notification | Da viet | |
| Misc | FakePlayer, ShulkerViewer, ChatIgnore, ChatNotify | Da viet | ShulkerViewer: hien noi dung shulker dang cam |
| Chi co o Noxilon (ngoai pham vi yeu cau) | BotPvp, ThrowXP, AutoEZ, ChatAppend, command system, friends, Baritone bridge | Khong lam | |

## API da xac minh (xuat hien trong bytecode Noxilon 26.2)
GuiGraphicsExtractor.{fill,fillGradient,text,item,itemDecorations,enableScissor,disableScissor,guiWidth,guiHeight},
Screen.{extractRenderState,extractBackground,mouseClicked(MouseButtonEvent,boolean),keyPressed(KeyEvent),charTyped(CharacterEvent)},
Gui.{screen,setScreen,hud}, Hud.getChat, ChatComponent.addClientSystemMessage, KeyboardHandler.keyPress,
Connection.channelRead0, HudElementRegistry.addLast, Identifier.fromNamespaceAndPath, MultiPlayerGameMode.{useItemOn,attack,handleContainerInput},
ServerboundMovePlayerPacket.{Rot,StatusOnly}, ClientboundSetEntityMotionPacket.{id,movement}, ClientboundExplodePacket.playerKnockback.

## API dung nhung CHUA xac minh (se lo ra o buoc compile neu sai)
KeyMapping.isDown, OptionInstance.get, LocalPlayer.{getHealth,getAbilities,isFallFlying,fallDistance(double)},
ItemStack.{isStackable,isSameItemSameComponents}, RespawnAnchorBlock.CHARGE, ClientReceiveMessageEvents.{ALLOW_CHAT,ALLOW_GAME} (chu ky lambda),
AABB.getCenter, Level.{OVERWORLD,NETHER}, Direction.Plane.HORIZONTAL (da thay iterator trong Noxilon).

| Misc | DiscordNotifier | Da viet | Lenh /dn + webhook (tu DiscordNotifierMod.class, target 26.1.2) |
