#!/usr/bin/env bash
# Step 2 - fetch Fabric build files and pin the Minecraft 26.1.2 versions.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/env.sh
python3 scripts/bootstrap.py 2>&1 | tee bootstrap.log
