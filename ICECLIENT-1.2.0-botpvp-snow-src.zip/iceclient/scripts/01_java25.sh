#!/usr/bin/env bash
# Step 1 - make sure Java 25 is installed (Codespaces ships with SDKMAN).
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/env.sh

major() { java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/'; }
if command -v java >/dev/null 2>&1 && [ "$(major)" -ge 25 ] 2>/dev/null; then
  echo "[OK] Java $(major) already available: $(command -v java)"
  exit 0
fi

echo "[..] Installing Java 25 with SDKMAN"
if [ ! -s "$HOME/.sdkman/bin/sdkman-init.sh" ]; then
  curl -s "https://get.sdkman.io" | bash
fi
set +u
source "$HOME/.sdkman/bin/sdkman-init.sh"
mkdir -p "$HOME/.sdkman/etc"
grep -q sdkman_auto_answer "$HOME/.sdkman/etc/config" 2>/dev/null || echo "sdkman_auto_answer=true" >> "$HOME/.sdkman/etc/config"
ID=$(sdk list java | grep -oE '25(\.[0-9]+)*-tem' | sort -V | tail -1 || true)
if [ -z "${ID:-}" ]; then
  echo "[ERR] Khong tim thay Temurin 25 trong 'sdk list java'. Chay: sdk list java | grep 25"
  exit 1
fi
sdk install java "$ID"
sdk default java "$ID"
set -u
source scripts/env.sh
echo "[OK] $(java -version 2>&1 | head -1)"
