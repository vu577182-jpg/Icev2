#!/usr/bin/env bash
# Sourced by the other scripts: prefer the SDKMAN Java 25 if present.
if [ -d "$HOME/.sdkman/candidates/java/current" ]; then
  export JAVA_HOME="$HOME/.sdkman/candidates/java/current"
  export PATH="$JAVA_HOME/bin:$PATH"
fi
