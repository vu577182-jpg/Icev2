# ICECLIENT 26.1.2 (Fabric, Java 25)

Client-side mod doc lap (package `com.iceclient`), ClickGUI "ICE PRO". Khong dung ma nguon cua Noxilon;
JAR tham khao chi duoc dung de xac dinh pham vi chuc nang va chu ky API Minecraft 26.1.2.

## Build tren GitHub Codespaces (copy/paste tung buoc)

```bash
unzip -o ICECLIENT-project.zip && cd iceclient     # neu chua giai nen
bash scripts/01_java25.sh                           # cai Java 25
bash scripts/02_bootstrap.sh                        # lay build script Fabric + ghim phien ban 26.1.2
bash scripts/03_build.sh                            # build + kiem tra JAR -> ICECLIENT.jar
```

Neu loi: `tail -n 60 build.log` roi gui cho Claude. Chay thu: chep `ICECLIENT.jar` vao `.minecraft/mods`
cung Fabric API, mo Minecraft 26.1.2 (Fabric Loader 0.19.3+), roi `bash scripts/05_checklog.sh duong/dan/latest.log`.

## Su dung
- **Right Shift**: mo ClickGUI. Click trai = bat/tat module, click phai = mo setting, keybind editor trong the module.
- Thanh tim kiem o header, Config manager o tab `Configs` (luu tai `config/iceclient/*.json`, `default` tu dong).
- Tinh the bang chi ve ben trong khung menu, khong ve ra man hinh game.

## Cau truc
`client/ module/{combat,movement,player,render,misc,hud,client}/ gui/ setting/ event/ manager/ config/ mixin/ util/`
