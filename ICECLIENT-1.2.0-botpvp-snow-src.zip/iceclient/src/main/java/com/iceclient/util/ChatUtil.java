package com.iceclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class ChatUtil {
    private ChatUtil() {}

    /** Prints a client-side-only line to chat. */
    public static void info(String message) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gui == null) return;
        mc.gui.hud.getChat().addClientSystemMessage(Component.literal("§b[ICE]§r " + message));
    }
}
