package com.iceclient.module.movement;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;

public final class AutoWalk extends Module {
    private final BooleanSetting pauseInGui = add(new BooleanSetting("PauseInGui", "Release the key while a screen is open", true));

    public AutoWalk() {
        super("AutoWalk", "Tu dong di thang ve phia truoc.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        boolean screen = mc.gui.screen() != null;
        mc.options.keyUp.setDown(!(pauseInGui.on() && screen));
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) mc.options.keyUp.setDown(false);
    }
}
