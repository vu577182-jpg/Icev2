package com.iceclient.module;

import com.iceclient.client.Ice;
import com.iceclient.manager.NotificationManager;
import com.iceclient.setting.Setting;
import com.iceclient.util.Animation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getInstance();

    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();

    private int key = -1;
    private boolean enabled;

    // UI animation state (owned by the module so it survives GUI re-opens)
    public final Animation guiToggle = new Animation(0f);
    public final Animation guiExpand = new Animation(0f);
    public final Animation hudSlide = new Animation(0f, 10f);
    public boolean guiExpanded;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    // ---- lifecycle hooks -------------------------------------------------
    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    public void onRender2D(GuiGraphicsExtractor g) {}

    /** Extra text shown after the name in the ArrayList (e.g. a mode). */
    public String info() { return ""; }

    /** HUD overlays and pure-options modules can run outside a world. */
    protected boolean requiresWorld() { return true; }

    /** Hidden modules do not appear in ClickGUI or ArrayList HUD. */
    public boolean isHidden() { return false; }

    /** Extra activation precondition. Return a reason to refuse, or null to allow. */
    protected String checkCanEnable() { return null; }

    // ---- state -------------------------------------------------------------
    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public boolean isWorldReady() { return mc.player != null && mc.level != null; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        if (value) {
            if (requiresWorld() && !isWorldReady()) {
                NotificationManager.warn(name, "Vao the gioi truoc khi bat module");
                return;
            }
            String reason = safeReason();
            if (reason != null) {
                NotificationManager.warn(name, reason);
                return;
            }
            enabled = true;
            try {
                onEnable();
            } catch (Throwable t) {
                fail("onEnable", t);
                return;
            }
        } else {
            enabled = false;
            try {
                onDisable();
            } catch (Throwable t) {
                Ice.LOGGER.error("{}: onDisable failed", name, t);
            }
        }
        if (category != Category.CLIENT) NotificationManager.toggled(this);
    }

    /** Sets state without side effects (config loading of HUD defaults). */
    public void setEnabledSilently(boolean value) { this.enabled = value; }

    private String safeReason() {
        try {
            return checkCanEnable();
        } catch (Throwable t) {
            Ice.LOGGER.error("{}: checkCanEnable failed", name, t);
            return "Loi kiem tra dieu kien";
        }
    }

    /** Safe-error handling: a crashing module is switched off instead of crashing the game. */
    public void fail(String where, Throwable t) {
        Ice.LOGGER.error("{} crashed in {} - disabling", name, where, t);
        enabled = false;
        try { onDisable(); } catch (Throwable ignored) { }
        NotificationManager.error(name, "Loi: " + t.getClass().getSimpleName() + " (da tat)");
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }
}
