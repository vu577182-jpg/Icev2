package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.Render2D;
import com.iceclient.util.Theme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.ShulkerBoxBlock;

/** Shows the contents of the shulker box you are holding (main hand, then off hand). */
public final class ShulkerViewer extends Module {
    private final NumberSetting yOffset = add(new NumberSetting("Y", "Offset above the hotbar", 100, 40, 260, 1));

    public ShulkerViewer() {
        super("ShulkerViewer", "Xem noi dung shulker box dang cam tren tay.", Category.MISC);
    }

    @Override protected boolean requiresWorld() { return false; }

    private static boolean isShulker(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock;
    }

    @Override
    public void onRender2D(GuiGraphicsExtractor g) {
        ItemStack held = mc.player.getMainHandItem();
        if (!isShulker(held)) held = mc.player.getOffhandItem();
        if (!isShulker(held)) return;

        NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);
        ItemContainerContents contents = held.get(DataComponents.CONTAINER);
        if (contents != null) contents.copyInto(items);

        int w = 9 * 18 + 8, h = 3 * 18 + 22;
        int x = (g.guiWidth() - w) / 2;
        int y = g.guiHeight() - yOffset.i() - h;
        Render2D.panel(g, x, y, w, h, Theme.alpha(Theme.BG, 0xE6), Theme.BORDER);
        g.text(mc.font, held.getHoverName(), x + 5, y + 5, Theme.SECONDARY, false);
        for (int i = 0; i < 27; i++) {
            int sx = x + 4 + (i % 9) * 18;
            int sy = y + 18 + (i / 9) * 18;
            Render2D.rect(g, sx, sy, 17, 17, Theme.alpha(Theme.CARD, 0xFF));
            ItemStack s = items.get(i);
            if (!s.isEmpty()) {
                g.item(s, sx + 1, sy + 1);
                g.itemDecorations(mc.font, s, sx + 1, sy + 1);
            }
        }
    }
}
