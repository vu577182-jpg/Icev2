package com.iceclient.mixin;

import com.iceclient.module.misc.Freecam;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class FreecamCameraMixin {

    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPosition(double x, double y, double z);

    /**
     * Inject ở TAIL của Camera.setup() (tên mapped: update / setup).
     * Override rotation và position nếu Freecam đang bật.
     *
     * Tên method có thể khác tuỳ mapping (yarn: update, mojmap: setup).
     * Nếu build fail đổi "update" thành "setup" hoặc seach trong remapped jar.
     */
    @Inject(
        method = "setup",
        at = @At("TAIL")
    )
    private void freecam$setup(CallbackInfo ci) {
        if (!Freecam.active) return;

        setRotation(Freecam.freeYaw, Freecam.freePitch);
        setPosition(Freecam.freeX, Freecam.freeY, Freecam.freeZ);
    }
}
