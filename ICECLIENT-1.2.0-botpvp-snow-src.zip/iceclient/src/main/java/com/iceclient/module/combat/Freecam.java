package com.iceclient.module.misc;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.CameraType;
import net.minecraft.client.player.LocalPlayer;

/**
 * Freecam — tách camera ra khỏi player, di chuyển tự do.
 *
 * Inject qua 2 mixin:
 *   FreecamCameraMixin  — override Camera.update() để set vị trí + rotation
 *   FreecamMouseMixin   — capture mouse delta để cập nhật freeYaw/Pitch
 *
 * State tĩnh (static) để mixin truy cập không cần ModuleManager lookup.
 */
public final class Freecam extends Module {

    // ---- settings -----------------------------------------------------------
    public final NumberSetting hSpeed = add(new NumberSetting(
            "HorizontalSpeed", "Tốc độ di chuyển ngang.", 1.0f, 0.1f, 10f
    ));
    public final NumberSetting vSpeed = add(new NumberSetting(
            "VerticalSpeed", "Tốc độ di chuyển dọc.", 1.0f, 0.1f, 10f
    ));
    public final BooleanSetting rotate = add(new BooleanSetting(
            "Rotate", "Xoay model player theo camera.", false
    ));

    // ---- static camera state (mixin đọc trực tiếp) -------------------------
    public static boolean active = false;

    public static double freeX, freeY, freeZ;
    public static double prevFreeX, prevFreeY, prevFreeZ;
    public static float  freeYaw, freePitch;
    public static float  prevFreeYaw, prevFreePitch;
    public static CameraType prevCameraType;

    // ---- instance -----------------------------------------------------------
    public static Freecam INSTANCE;

    public Freecam() {
        super("Freecam", "Di chuyển camera tự do.", Category.MISC);
        INSTANCE = this;

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!isEnabled() || client.player == null) return;
            tickMovement(client.player);
        });
    }

    @Override
    protected void onEnable() {
        LocalPlayer p = mc.player;
        if (p == null) { setEnabled(false); return; }

        freeX = prevFreeX = p.getX();
        freeY = prevFreeY = p.getY() + p.getEyeHeight(p.getPose());
        freeZ = prevFreeZ = p.getZ();
        freeYaw   = prevFreeYaw   = p.getYRot();
        freePitch = prevFreePitch = p.getXRot();

        prevCameraType = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        active = true;
    }

    @Override
    protected void onDisable() {
        if (prevCameraType != null) {
            mc.options.setCameraType(prevCameraType);
        }
        active = false;
    }

    // ---- movement per tick -------------------------------------------------
    private void tickMovement(LocalPlayer p) {
        prevFreeX   = freeX;
        prevFreeY   = freeY;
        prevFreeZ   = freeZ;
        prevFreeYaw   = freeYaw;
        prevFreePitch = freePitch;

        float yawRad = (float) Math.toRadians(freeYaw);
        float hs = hSpeed.getFloat() * 0.1f;
        float vs = vSpeed.getFloat() * 0.1f;

        float forward  = p.input.forwardImpulse;
        float sideways = p.input.leftImpulse;

        // forward/back
        freeX -= Math.sin(yawRad) * forward * hs;
        freeZ += Math.cos(yawRad) * forward * hs;
        // strafe
        double strafeYaw = Math.toRadians(freeYaw + 90);
        freeX -= Math.sin(strafeYaw) * sideways * hs;
        freeZ += Math.cos(strafeYaw) * sideways * hs;
        // up/down
        if (mc.options.keyJump.isDown())  freeY += vs;
        if (mc.options.keyShift.isDown()) freeY -= vs;
    }

    /** MouseMixin gọi để cập nhật yaw/pitch từ mouse delta. */
    public static void onMouseTurn(double dx, double dy) {
        if (!active) return;
        float sensitivity = 0.15f;
        freeYaw   += (float)(dx * sensitivity);
        freePitch  = net.minecraft.util.Mth.clamp(
                freePitch + (float)(dy * sensitivity), -90f, 90f);
    }
}
