package com.iceclient.module.combat;

import com.iceclient.module.Category;
import com.iceclient.module.Module;
import com.iceclient.module.ModuleManager;
import com.iceclient.setting.BooleanSetting;
import com.iceclient.setting.NumberSetting;
import com.iceclient.util.InventoryUtil;
import com.iceclient.util.RotationUtil;
import com.iceclient.util.TargetUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * PvP bot core loop ported/adapted from Noxilon (Shimeji) BotPvp.
 * Does NOT use Baritone — movement is key-simulation + rotation.
 *
 * Features:
 *  - Target nearest player
 *  - Aimbot (silent rotation packets and/or face client camera)
 *  - Auto attack in range
 *  - Follow toward target
 *  - Sprint while following
 *  - Trigger Surround when crystal is nearby
 *  - Pearl toward target when far (optional)
 */
public final class BotPvp extends Module {

    private final NumberSetting targetRange = add(new NumberSetting("TargetRange", "Max distance to pick a target", 24, 4, 64, 0.5));
    private final NumberSetting followDistance = add(new NumberSetting("FollowDistance", "Stop walking when closer than this", 2.2, 0.5, 6, 0.1));
    private final NumberSetting attackRange = add(new NumberSetting("AttackRange", "Melee attack reach", 3.2, 1, 6, 0.1));
    private final NumberSetting pearlDistance = add(new NumberSetting("PearlDistance", "Throw pearl if target farther than this", 12, 4, 40, 0.5));
    private final NumberSetting pearlCooldown = add(new NumberSetting("PearlCooldown", "Ticks between pearl throws", 40, 10, 200, 1));
    private final NumberSetting surroundCrystalRange = add(new NumberSetting("SurroundCrystalRange", "Trigger Surround when crystal within", 5, 1, 12, 0.5));

    private final BooleanSetting aimbot = add(new BooleanSetting("Aimbot", "Rotate toward the target", true));
    private final BooleanSetting silentRotate = add(new BooleanSetting("SilentRotate", "Server-only rotation (camera stays)", true));
    private final BooleanSetting faceTarget = add(new BooleanSetting("FaceTarget", "Also turn client camera toward target", false));
    private final BooleanSetting autoAttack = add(new BooleanSetting("AutoAttack", "Attack target in range", true));
    private final BooleanSetting follow = add(new BooleanSetting("Follow", "Walk toward the target", true));
    private final BooleanSetting sprint = add(new BooleanSetting("Sprint", "Sprint while following", true));
    private final BooleanSetting jumpObstacles = add(new BooleanSetting("JumpObstacles", "Jump when blocked while following", true));
    private final BooleanSetting autoPearl = add(new BooleanSetting("AutoPearl", "Pearl toward far targets", false));
    private final BooleanSetting surroundOnCrystal = add(new BooleanSetting("SurroundOnCrystal", "Enable Surround when crystal nearby", true));
    private final BooleanSetting pauseInGui = add(new BooleanSetting("PauseInGui", "Pause bot while a screen is open", true));

    private Player target;
    private int pearlTicks;
    private int attackTicks;
    private boolean holdingKeys;

    public BotPvp() {
        super("BotPvp", "Bot PvP: follow, aim, attack, pearl, surround on crystal.", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        target = null;
        pearlTicks = 0;
        attackTicks = 0;
        holdingKeys = false;
    }

    @Override
    protected void onDisable() {
        releaseMovement();
        target = null;
    }

    @Override
    public void onTick() {
        LocalPlayer self = mc.player;
        if (self == null || mc.level == null || mc.gameMode == null) return;

        if (pauseInGui.on() && mc.gui.screen() != null) {
            releaseMovement();
            return;
        }

        if (pearlTicks > 0) pearlTicks--;
        if (attackTicks > 0) attackTicks--;

        target = TargetUtil.nearestPlayer(targetRange.d());
        if (target == null || !target.isAlive()) {
            releaseMovement();
            return;
        }

        double dist = self.distanceTo(target);
        Vec3 aimPoint = target.getEyePosition().add(0, -0.15, 0);

        // --- Aim ---
        if (aimbot.on()) {
            float[] rot = RotationUtil.to(aimPoint);
            if (silentRotate.on()) {
                RotationUtil.send(rot);
            }
            if (faceTarget.on() || !silentRotate.on()) {
                self.setYRot(rot[0]);
                self.setXRot(rot[1]);
            }
        }

        // --- Attack ---
        if (autoAttack.on() && dist <= attackRange.d() && attackTicks <= 0) {
            if (self.getAttackStrengthScale(0.5f) >= 0.9f) {
                mc.gameMode.attack(self, target);
                self.swing(InteractionHand.MAIN_HAND);
                attackTicks = 2;
            }
        }

        // --- Follow ---
        if (follow.on()) {
            if (dist > followDistance.d()) {
                walkToward(self, target.position());
            } else {
                releaseMovement();
            }
        }

        // --- Sprint ---
        if (sprint.on() && holdingKeys && dist > followDistance.d()) {
            self.setSprinting(true);
            mc.options.keySprint.setDown(true);
        }

        // --- Surround on crystal ---
        if (surroundOnCrystal.on() && hasNearbyCrystal(surroundCrystalRange.d())) {
            Surround s = ModuleManager.get(Surround.class);
            if (s != null && !s.isEnabled()) {
                s.setEnabled(true);
            }
        }

        // --- Pearl ---
        if (autoPearl.on() && dist >= pearlDistance.d() && pearlTicks <= 0) {
            if (throwPearl(aimPoint)) {
                pearlTicks = pearlCooldown.i();
            }
        }
    }

    private void walkToward(LocalPlayer self, Vec3 dest) {
        double dx = dest.x - self.getX();
        double dz = dest.z - self.getZ();
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float yaw = self.getYRot();
        float diff = Mth.wrapDegrees(targetYaw - yaw);

        // Release all, then set keys based on angle to target in local space
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);

        // Prefer turning + walking forward for smoother path
        if (Math.abs(diff) < 50) {
            mc.options.keyUp.setDown(true);
        } else if (diff > 0) {
            mc.options.keyRight.setDown(true);
            if (Math.abs(diff) < 120) mc.options.keyUp.setDown(true);
        } else {
            mc.options.keyLeft.setDown(true);
            if (Math.abs(diff) < 120) mc.options.keyUp.setDown(true);
        }

        if (jumpObstacles.on() && self.horizontalCollision && self.onGround()) {
            mc.options.keyJump.setDown(true);
        } else {
            mc.options.keyJump.setDown(false);
        }

        holdingKeys = true;
    }

    private void releaseMovement() {
        if (mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keySprint.setDown(false);
        holdingKeys = false;
    }

    private boolean hasNearbyCrystal(double range) {
        LocalPlayer self = mc.player;
        AABB box = self.getBoundingBox().inflate(range);
        for (EndCrystal c : mc.level.getEntitiesOfClass(EndCrystal.class, box)) {
            if (c.isAlive() && self.distanceTo(c) <= range) return true;
        }
        return false;
    }

    private boolean throwPearl(Vec3 toward) {
        int slot = InventoryUtil.findHotbar(Items.ENDER_PEARL);
        if (slot < 0) return false;
        int prev = InventoryUtil.selected();
        InventoryUtil.select(slot);
        float[] rot = RotationUtil.to(toward);
        RotationUtil.send(rot);
        // Slight pitch up for distance
        RotationUtil.send(rot[0], Math.max(-60f, rot[1] - 8f));
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        InventoryUtil.select(prev);
        return true;
    }

    @Override
    public String info() {
        if (target == null) return "no target";
        return target.getName().getString() + " " + String.format("%.1f", mc.player == null ? 0 : mc.player.distanceTo(target));
    }
}
