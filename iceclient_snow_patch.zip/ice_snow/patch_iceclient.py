#!/usr/bin/env python3
"""
ICE CLIENT — snowflake patch for IceScreen.java
Chạy từ thư mục gốc của project:
    python3 patch_iceclient.py

Script tự tìm IceScreen.java và chèn code snowflake vào đúng vị trí.
"""
import os, sys, re

# ------------------------------------------------------------------ paths ---
SEARCH_ROOTS = [".", "src", "iceclient/src"]
TARGET = "IceScreen.java"

def find_file(name, roots):
    for root in roots:
        for dirpath, _, files in os.walk(root):
            if name in files:
                return os.path.join(dirpath, name)
    return None

ice_path = find_file(TARGET, SEARCH_ROOTS)
if ice_path is None:
    sys.exit(f"[LỖII] Không tìm thấy {TARGET} — chạy script từ thư mục gốc project.")

print(f"[OK] Tìm thấy: {ice_path}")
with open(ice_path, "r", encoding="utf-8") as f:
    src = f.read()

# ---------------------------------------------------------------- guard ----
if "drawSnowflakes" in src:
    sys.exit("[SKIP] Snowflake code đã có trong file rồi, không cần patch lại.")

# -------------------------------------------------------- 1. add call ------
# Thêm drawSnowflakes(g); ngay sau dòng "drawIce(g);"
OLD_CALL = "        drawIce(g);\n    }"
NEW_CALL = "        drawIce(g);\n        drawSnowflakes(g);\n    }"
if OLD_CALL not in src:
    sys.exit(f"[LỖI] Không tìm thấy landmark 'drawIce(g);' trong extractRenderState — file có thể đã bị sửa.")

src = src.replace(OLD_CALL, NEW_CALL, 1)
print("[OK] Đã thêm drawSnowflakes(g) vào extractRenderState")

# ------------------------------------------------ 2. insert methods --------
# Chèn trước comment // ---- helpers
SNOWFLAKE_METHODS = r"""
    // ======================================================================
    // snowflakes
    // ======================================================================
    private static final int SNOW_N = 32;

    /** Animated snowflakes falling inside the menu frame, clipped to its interior. */
    private void drawSnowflakes(GuiGraphicsExtractor g) {
        ClickGui cg = ModuleManager.get(ClickGui.class);
        if (cg == null || !cg.snow.on()) return;

        int clipX1 = x0 + 1,  clipY1 = y0 + HEADER + 1;
        int clipX2 = x0 + fw - 1, clipY2 = y0 + fh - 1;
        g.enableScissor(clipX1, clipY1, clipX2, clipY2);

        float time  = (System.currentTimeMillis() % 200_000L) / 1000f;
        int snowW = fw - 2;
        int snowH = fh - HEADER - 2;

        for (int i = 0; i < SNOW_N; i++) {
            float phase    = i * 2.39996f;                      // golden-angle spread
            float speed    = 14f + (phase % 1f) * 18f;          // 14–32 px/sec
            float driftAmp = 2.5f + (phase * 1.3f % 5f);
            float driftSpd = 0.3f + (phase * 0.9f % 0.7f);
            int   sz       = 1 + (i % 3);                       // 1, 2, or 3 px radius

            float relY = (time * speed + (phase % 1f) * snowH) % (snowH + sz * 2 + 4);
            float relX = (phase % 1f) * snowW
                       + driftAmp * (float) Math.sin(time * driftSpd + phase);

            // fade at top / bottom edges
            float fadeIn  = Math.min(1f, relY / 24f);
            float fadeOut = Math.min(1f, (snowH - relY) / 24f);
            float pulse   = 0.28f + 0.22f * (float) Math.sin(time * 1.6f + phase);
            int   alpha   = (int)(Math.max(0f, Math.min(1f, pulse * fadeIn * fadeOut)) * 255f);
            if (alpha < 10) continue;

            int fx = clipX1 + (int) relX;
            int fy = clipY1 + (int) relY;
            if (fx < clipX1 + sz + 1 || fx > clipX2 - sz - 1) continue;

            drawSnowflake(g, fx, fy, sz, Theme.alpha(Theme.SECONDARY, alpha));
        }
        g.disableScissor();
    }

    /**
     * 8-arm pixel snowflake centred on (cx, cy).
     * Arms: horizontal, vertical, and both diagonals.
     */
    private void drawSnowflake(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        // horizontal
        g.fill(cx - r, cy,     cx + r + 1, cy + 1,     color);
        // vertical
        g.fill(cx,     cy - r, cx + 1,     cy + r + 1, color);
        // diagonals (45°)
        for (int d = 1; d <= r; d++) {
            g.fill(cx - d, cy - d, cx - d + 1, cy - d + 1, color); // NW
            g.fill(cx + d, cy - d, cx + d + 1, cy - d + 1, color); // NE
            g.fill(cx - d, cy + d, cx - d + 1, cy + d + 1, color); // SW
            g.fill(cx + d, cy + d, cx + d + 1, cy + d + 1, color); // SE
        }
    }

"""

LANDMARK = "    // ---- helpers"
if LANDMARK not in src:
    sys.exit(f"[LỖI] Không tìm thấy '{LANDMARK}' — file có thể đã bị sửa.")

src = src.replace(LANDMARK, SNOWFLAKE_METHODS + LANDMARK, 1)
print("[OK] Đã chèn drawSnowflakes() và drawSnowflake() methods")

# ------------------------------------------------------ 3. write back ------
backup = ice_path + ".bak"
import shutil
shutil.copy2(ice_path, backup)
print(f"[OK] Backup: {backup}")

with open(ice_path, "w", encoding="utf-8") as f:
    f.write(src)

print(f"[XONG] Đã patch {ice_path}")
print("       Build lại bình thường: ./gradlew build")
